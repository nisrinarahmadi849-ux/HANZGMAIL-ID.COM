import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { ScrollText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/rules")({
  head: () => ({ meta: [{ title: "Rules — HANZGMAIL" }] }),
  component: RulesPage,
});

function RulesPage() {
  const { data } = useQuery({
    queryKey: ["rules"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("value").eq("key", "rules_text").maybeSingle();
      return typeof data?.value === "string" ? data.value : "";
    },
  });

  return (
    <div className="max-w-3xl space-y-6">
      <div className="flex items-center gap-3">
        <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
          <ScrollText className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">Rules</h1>
          <p className="text-sm text-muted-foreground">Baca aturan sebelum menyetorkan Gmail</p>
        </div>
      </div>
      <Card className="p-6 card-elevated">
        <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">{data || "Belum ada rules."}</pre>
      </Card>
    </div>
  );
}
