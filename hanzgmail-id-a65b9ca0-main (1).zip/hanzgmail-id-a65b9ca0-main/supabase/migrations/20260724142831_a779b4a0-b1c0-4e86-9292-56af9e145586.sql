
REVOKE ALL ON FUNCTION public.on_profile_verified() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.on_gmail_status_change() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.on_withdrawal_status_change() FROM PUBLIC, anon, authenticated;
