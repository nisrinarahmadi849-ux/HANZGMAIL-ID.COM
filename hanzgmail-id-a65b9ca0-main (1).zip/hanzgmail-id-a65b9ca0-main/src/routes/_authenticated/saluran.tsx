import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MessageCircle, Send, Hash, ExternalLink } from "lucide-react";

export const Route = createFileRoute("/_authenticated/saluran")({
  head: () => ({ meta: [{ title: "Saluran — HANZGMAIL" }] }),
  component: SaluranPage,
});

function SaluranPage() {
  const { data } = useQuery({
    queryKey: ["saluran-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("key, value").in("key", ["whatsapp_admin", "telegram_link", "discord_link"]);
      const m: Record<string, string> = {};
      data?.forEach((r) => (m[r.key] = typeof r.value === "string" ? r.value : ""));
      return m;
    },
  });

  const wa = data?.whatsapp_admin ? `https://wa.me/${data.whatsapp_admin.replace(/[^0-9]/g, "")}` : "";
  const tg = data?.telegram_link ?? "";
  const dc = data?.discord_link ?? "";

  const channels = [
    { label: "WhatsApp", href: wa, icon: MessageCircle, color: "bg-emerald-500/10 text-emerald-600" },
    { label: "Telegram", href: tg, icon: Send, color: "bg-sky-500/10 text-sky-600" },
    { label: "Discord", href: dc, icon: Hash, color: "bg-indigo-500/10 text-indigo-600" },
  ];

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Saluran Resmi</h1>
        <p className="text-sm text-muted-foreground">Ikuti channel resmi untuk update dan bantuan</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        {channels.map((c) => (
          <Card key={c.label} className="p-5 card-elevated flex flex-col items-start gap-3 hover:shadow-[var(--shadow-glow)] transition-shadow">
            <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${c.color}`}>
              <c.icon className="h-5 w-5" />
            </div>
            <div className="font-display font-semibold">{c.label}</div>
            <Button size="sm" className="w-full" disabled={!c.href} asChild={!!c.href}>
              {c.href ? (
                <a href={c.href} target="_blank" rel="noreferrer">
                  Buka <ExternalLink className="h-3.5 w-3.5 ml-1" />
                </a>
              ) : (
                <span>Belum diatur</span>
              )}
            </Button>
          </Card>
        ))}
      </div>
    </div>
  );
}
