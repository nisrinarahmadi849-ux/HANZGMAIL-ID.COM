import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/reset-password")({
  ssr: false,
  head: () => ({ meta: [{ title: "Reset Password — HANZGMAIL.ID" }] }),
  component: ResetPage,
});

function ResetPage() {
  const router = useRouter();
  const [pw, setPw] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Password berhasil diubah");
    router.navigate({ to: "/dashboard" });
  };
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md p-6 glass">
        <h1 className="font-display font-bold text-xl mb-4">Reset Password</h1>
        <form onSubmit={submit} className="space-y-3">
          <div>
            <Label htmlFor="np">Password Baru</Label>
            <Input id="np" type="password" minLength={8} value={pw} onChange={(e) => setPw(e.target.value)} required />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? "Memproses..." : "Ubah Password"}
          </Button>
        </form>
      </Card>
    </div>
  );
}
