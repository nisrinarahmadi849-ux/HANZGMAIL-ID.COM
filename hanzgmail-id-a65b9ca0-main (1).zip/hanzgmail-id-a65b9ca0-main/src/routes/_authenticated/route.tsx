import { createFileRoute, Outlet, redirect, Link, useRouter, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { SidebarProvider, useSidebar } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { LogOut, Bell, ArrowLeft, Menu } from "lucide-react";
import { toast } from "sonner";

function MenuButton() {
  const { toggleSidebar } = useSidebar();
  return (
    <Button variant="outline" size="sm" onClick={toggleSidebar} className="h-9 px-2.5 gap-1.5" aria-label="Buka menu">
      <Menu className="h-4 w-4" />
      <span className="text-sm font-medium">Menu</span>
    </Button>
  );
}
import { useQuery, useQueryClient } from "@tanstack/react-query";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: Layout,
});

function Layout() {
  const router = useRouter();
  const qc = useQueryClient();
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const canGoBack = pathname !== "/dashboard" && pathname !== "/";

  const { data: unread } = useQuery({
    queryKey: ["unread-count"],
    queryFn: async () => {
      const { count } = await supabase
        .from("notifications")
        .select("*", { count: "exact", head: true })
        .eq("read", false);
      return count ?? 0;
    },
    refetchInterval: 15000,
  });

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    toast.success("Berhasil logout");
    router.navigate({ to: "/auth", replace: true });
  };

  const goBack = () => {
    if (typeof window !== "undefined" && window.history.length > 1) {
      window.history.back();
    } else {
      router.navigate({ to: "/dashboard" });
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-background">
        <AppSidebar />
        <div className="flex-1 flex flex-col min-w-0">
          <header className="h-14 flex items-center justify-between border-b bg-card/70 backdrop-blur px-3 sm:px-4 gap-2 sticky top-0 z-30">
            <div className="flex items-center gap-1.5">
              <MenuButton />
              {canGoBack && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={goBack}
                  className="h-9 px-2.5 gap-1.5"
                  aria-label="Kembali"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span className="hidden sm:inline">Kembali</span>
                </Button>
              )}
            </div>
            <div className="flex items-center gap-1">
              <Button variant="ghost" size="icon" asChild className="relative">
                <Link to="/notifikasi" aria-label="Notifikasi">
                  <Bell className="h-4 w-4" />
                  {unread ? (
                    <span className="absolute -top-0.5 -right-0.5 h-4 min-w-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-semibold flex items-center justify-center">
                      {unread}
                    </span>
                  ) : null}
                </Link>
              </Button>
              <ThemeToggle />
              <Button variant="ghost" size="icon" onClick={signOut} aria-label="Logout">
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 overflow-x-hidden">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
