import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/status-badge";
import { rupiah, formatDate } from "@/lib/format";
import { Search, Ban, CheckCircle2, Plus, Minus, BadgeCheck, KeyRound, ShieldOff, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/_authenticated/admin/users")({
  head: () => ({ meta: [{ title: "Admin Users — HANZGMAIL" }] }),
  component: AdminUsers,
});

type Row = {
  id: string;
  username: string;
  email: string | null;
  full_name: string | null;
  status: string;
  verified: boolean;
  created_at: string;
  balance: number;
};

const PAGE = 20;

function AdminUsers() {
  const qc = useQueryClient();
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");

  const { data } = useQuery({
    queryKey: ["admin-users", page, q],
    queryFn: async () => {
      let query = supabase
        .from("profiles")
        .select("id, username, email, full_name, status, verified, created_at", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(page * PAGE, page * PAGE + PAGE - 1);
      if (q) query = query.ilike("username", `%${q}%`);
      const { data: profiles, count } = await query;
      const ids = (profiles ?? []).map((p) => p.id);
      const { data: bals } = ids.length
        ? await supabase.from("balances").select("user_id, balance").in("user_id", ids)
        : { data: [] as { user_id: string; balance: number }[] };
      const balMap = new Map((bals ?? []).map((b) => [b.user_id, Number(b.balance)]));
      const rows: Row[] = ((profiles ?? []) as Omit<Row, "balance">[]).map((p) => ({ ...p, balance: balMap.get(p.id) ?? 0 }));
      return { rows, count: count ?? 0 };
    },
  });

  const setStatus = async (id: string, next: "active" | "suspended" | "banned") => {
    const { error } = await supabase.from("profiles").update({ status: next }).eq("id", id);
    if (error) toast.error(error.message);
    else {
      const label =
        next === "active" ? "User diaktifkan" : next === "suspended" ? "User di-suspend" : "User di-BAN";
      toast.success(label);
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    }
  };

  const toggleVerified = async (id: string, current: boolean) => {
    const { error } = await supabase.from("profiles").update({ verified: !current }).eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success(!current ? "User diverifikasi" : "Verifikasi dibatalkan");
      qc.invalidateQueries({ queryKey: ["admin-users"] });
    }
  };

  const resetPassword = async (email: string | null) => {
    if (!email) return toast.error("User tidak punya email");
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + "/reset-password",
    });
    if (error) toast.error(error.message);
    else toast.success("Link reset password dikirim ke " + email);
  };

  const total = data?.count ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <Card className="p-4 card-elevated">
      <div className="flex flex-wrap gap-2 mb-3">
        <div className="relative flex-1 min-w-56">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Cari username..." className="pl-8" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Bergabung</TableHead>
              <TableHead>Username</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Saldo</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data?.rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatDate(r.created_at)}</TableCell>
                <TableCell className="font-medium">
                  <span className="inline-flex items-center gap-1">
                    {r.username}
                    {r.verified && <BadgeCheck className="h-3.5 w-3.5 text-primary" />}
                  </span>
                </TableCell>
                <TableCell>{r.email}</TableCell>
                <TableCell className="font-semibold">{rupiah(r.balance)}</TableCell>
                <TableCell><StatusBadge status={r.status} /></TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <BalanceDialog userId={r.id} currentBalance={r.balance} />
                  <Button size="icon" variant="ghost" onClick={() => toggleVerified(r.id, r.verified)} aria-label="verify" title={r.verified ? "Batalkan verifikasi" : "Verifikasi"}>
                    <BadgeCheck className={`h-4 w-4 ${r.verified ? "text-primary" : "text-muted-foreground"}`} />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => resetPassword(r.email)} aria-label="reset" title="Reset password">
                    <KeyRound className="h-4 w-4" />
                  </Button>
                  {r.status !== "active" ? (
                    <Button size="icon" variant="ghost" onClick={() => setStatus(r.id, "active")} aria-label="activate" title="Aktifkan">
                      <ShieldCheck className="h-4 w-4 text-success" />
                    </Button>
                  ) : null}
                  {r.status !== "suspended" ? (
                    <Button size="icon" variant="ghost" onClick={() => setStatus(r.id, "suspended")} aria-label="suspend" title="Suspend sementara">
                      <Ban className="h-4 w-4 text-warning" />
                    </Button>
                  ) : null}
                  {r.status !== "banned" ? (
                    <Button size="icon" variant="ghost" onClick={() => { if (confirm("Ban user permanen?")) setStatus(r.id, "banned"); }} aria-label="ban" title="Ban permanen">
                      <ShieldOff className="h-4 w-4 text-destructive" />
                    </Button>
                  ) : null}
                </TableCell>
              </TableRow>
            ))}
            {!data?.rows.length && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6">Tidak ada data</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-between mt-3 text-sm">
        <span className="text-muted-foreground">Total: {total}</span>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}>Prev</Button>
          <span className="px-3 py-1">{page + 1} / {pages}</span>
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1}>Next</Button>
        </div>
      </div>
    </Card>
  );
}

function BalanceDialog({ userId, currentBalance }: { userId: string; currentBalance: number }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  const adjust = async (mode: "add" | "sub") => {
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast.error("Nominal tidak valid");
    const delta = mode === "add" ? amt : -amt;
    const newBalance = Number(currentBalance) + delta;
    if (newBalance < 0) return toast.error("Saldo hasil tidak boleh negatif");

    const { error: e1 } = await supabase
      .from("balances")
      .update({ balance: newBalance, updated_at: new Date().toISOString() })
      .eq("user_id", userId);
    if (e1) return toast.error(e1.message);

    const { error: e2 } = await supabase.from("transactions").insert({
      user_id: userId,
      type: mode === "add" ? "manual_credit" : "manual_debit",
      amount: delta,
      balance_after: newBalance,
      description: note || (mode === "add" ? "Penambahan saldo manual" : "Pengurangan saldo manual"),
    });
    if (e2) return toast.error(e2.message);

    await supabase.from("notifications").insert({
      user_id: userId,
      type: "manual_adjust",
      title: mode === "add" ? "Saldo Ditambahkan" : "Saldo Dikurangi",
      message: (note || "Penyesuaian saldo oleh admin") + " (" + rupiah(Math.abs(delta)) + ")",
    });

    toast.success("Saldo diperbarui");
    setOpen(false);
    setAmount("");
    setNote("");
    qc.invalidateQueries({ queryKey: ["admin-users"] });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost" aria-label="Adjust balance" title="Sesuaikan saldo">
          <Plus className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Sesuaikan Saldo</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm">
            Saldo saat ini: <strong>{rupiah(currentBalance)}</strong>
          </div>
          <div>
            <Label htmlFor="amt">Nominal</Label>
            <Input id="amt" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="nt">Catatan</Label>
            <Input id="nt" value={note} onChange={(e) => setNote(e.target.value)} placeholder="Opsional" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => adjust("sub")}>
            <Minus className="h-4 w-4 mr-1" /> Kurangi
          </Button>
          <Button onClick={() => adjust("add")}>
            <Plus className="h-4 w-4 mr-1" /> Tambah
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
