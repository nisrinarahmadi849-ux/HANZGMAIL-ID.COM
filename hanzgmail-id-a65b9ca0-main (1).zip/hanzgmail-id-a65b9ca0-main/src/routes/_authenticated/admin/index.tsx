import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { rupiah } from "@/lib/format";
import { Users, Mail, Clock, CheckCircle2, XCircle, Wallet } from "lucide-react";

export const Route = createFileRoute("/_authenticated/admin/")({
  head: () => ({ meta: [{ title: "Admin — HANZGMAIL.ID" }] }),
  component: AdminDash,
});

function AdminDash() {
  const { data } = useQuery({
    queryKey: ["admin-dash"],
    queryFn: async () => {
      const [users, gAll, gPend, gApp, gRej, wPend, wApp, wRej, balances] = await Promise.all([
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("status", "approved"),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("status", "rejected"),
        supabase.from("withdrawals").select("*", { count: "exact", head: true }).eq("status", "pending"),
        supabase.from("withdrawals").select("*", { count: "exact", head: true }).eq("status", "approved"),
        supabase.from("withdrawals").select("*", { count: "exact", head: true }).eq("status", "rejected"),
        supabase.from("balances").select("balance"),
      ]);
      const totalBalance = (balances.data ?? []).reduce((s, b) => s + Number(b.balance), 0);
      return {
        users: users.count ?? 0,
        gAll: gAll.count ?? 0,
        gPend: gPend.count ?? 0,
        gApp: gApp.count ?? 0,
        gRej: gRej.count ?? 0,
        wPend: wPend.count ?? 0,
        wApp: wApp.count ?? 0,
        wRej: wRej.count ?? 0,
        totalBalance,
      };
    },
  });

  const stats = [
    { label: "Total User", value: data?.users, icon: Users, cls: "text-primary bg-primary/10" },
    { label: "Gmail Masuk", value: data?.gAll, icon: Mail, cls: "text-primary bg-primary/10" },
    { label: "Gmail Pending", value: data?.gPend, icon: Clock, cls: "text-warning bg-warning/10" },
    { label: "Gmail Disetujui", value: data?.gApp, icon: CheckCircle2, cls: "text-success bg-success/10" },
    { label: "Gmail Ditolak", value: data?.gRej, icon: XCircle, cls: "text-destructive bg-destructive/10" },
    { label: "WD Pending", value: data?.wPend, icon: Clock, cls: "text-warning bg-warning/10" },
    { label: "WD Disetujui", value: data?.wApp, icon: CheckCircle2, cls: "text-success bg-success/10" },
    { label: "WD Ditolak", value: data?.wRej, icon: XCircle, cls: "text-destructive bg-destructive/10" },
    { label: "Total Saldo User", value: rupiah(data?.totalBalance ?? 0), icon: Wallet, cls: "text-primary bg-primary/10", full: true },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className={`p-4 card-elevated ${s.full ? "sm:col-span-2 lg:col-span-4" : ""}`}>
            <div className="flex items-center gap-3">
              <div className={`h-10 w-10 rounded-lg ${s.cls} flex items-center justify-center`}>
                <s.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-xl font-display font-bold">{s.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
