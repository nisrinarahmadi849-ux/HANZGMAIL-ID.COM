
-- ============ ENUMS ============
CREATE TYPE public.app_role AS ENUM ('admin', 'user');
CREATE TYPE public.submission_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE public.withdrawal_method AS ENUM ('dana', 'gopay');
CREATE TYPE public.tx_type AS ENUM ('gmail_reward', 'withdrawal', 'manual_credit', 'manual_debit');

-- ============ PROFILES ============
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT NOT NULL UNIQUE,
  full_name TEXT,
  email TEXT,
  status TEXT NOT NULL DEFAULT 'active', -- active | suspended
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- ============ USER ROLES ============
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE(user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- ============ BALANCES ============
CREATE TABLE public.balances (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  balance NUMERIC(14,2) NOT NULL DEFAULT 0,
  total_withdrawn NUMERIC(14,2) NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.balances TO authenticated;
GRANT ALL ON public.balances TO service_role;
ALTER TABLE public.balances ENABLE ROW LEVEL SECURITY;

-- ============ GMAIL SUBMISSIONS ============
CREATE TABLE public.gmail_submissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  gmail TEXT NOT NULL,
  status submission_status NOT NULL DEFAULT 'pending',
  price NUMERIC(14,2) NOT NULL DEFAULT 5000,
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.gmail_submissions(user_id);
CREATE INDEX ON public.gmail_submissions(status);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gmail_submissions TO authenticated;
GRANT ALL ON public.gmail_submissions TO service_role;
ALTER TABLE public.gmail_submissions ENABLE ROW LEVEL SECURITY;

-- ============ WITHDRAWALS ============
CREATE TABLE public.withdrawals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  method withdrawal_method NOT NULL,
  account_number TEXT NOT NULL,
  amount NUMERIC(14,2) NOT NULL CHECK (amount > 0),
  status submission_status NOT NULL DEFAULT 'pending',
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.withdrawals(user_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.withdrawals TO authenticated;
GRANT ALL ON public.withdrawals TO service_role;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;

-- ============ TRANSACTIONS ============
CREATE TABLE public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type tx_type NOT NULL,
  amount NUMERIC(14,2) NOT NULL,
  balance_after NUMERIC(14,2) NOT NULL,
  description TEXT,
  ref_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.transactions(user_id, created_at DESC);
GRANT SELECT ON public.transactions TO authenticated;
GRANT ALL ON public.transactions TO service_role;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- ============ NOTIFICATIONS ============
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ON public.notifications(user_id, created_at DESC);
GRANT SELECT, UPDATE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- ============ SETTINGS (CMS key-value) ============
CREATE TABLE public.settings (
  key TEXT PRIMARY KEY,
  value JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.settings TO authenticated, anon;
GRANT ALL ON public.settings TO service_role;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- ============ FEATURES ============
CREATE TABLE public.features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT,
  color TEXT,
  href TEXT,
  sort_order INT NOT NULL DEFAULT 0,
  enabled BOOLEAN NOT NULL DEFAULT true,
  visible BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.features TO authenticated, anon;
GRANT ALL ON public.features TO service_role;
ALTER TABLE public.features ENABLE ROW LEVEL SECURITY;

-- ============ CMS PAGES ============
CREATE TABLE public.cms_pages (
  slug TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.cms_pages TO authenticated, anon;
GRANT ALL ON public.cms_pages TO service_role;
ALTER TABLE public.cms_pages ENABLE ROW LEVEL SECURITY;

-- ============ AUDIT LOGS ============
CREATE TABLE public.audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  meta JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

-- ============ RLS POLICIES ============
-- profiles
CREATE POLICY "own profile read" ON public.profiles FOR SELECT TO authenticated
USING (auth.uid() = id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "own profile update" ON public.profiles FOR UPDATE TO authenticated
USING (auth.uid() = id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin insert/delete profiles" ON public.profiles FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin'))
WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- user_roles (read only for owner; admin manages via service_role)
CREATE POLICY "read own role" ON public.user_roles FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- balances
CREATE POLICY "read own balance" ON public.balances FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- gmail_submissions
CREATE POLICY "own submissions read" ON public.gmail_submissions FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "own submissions insert" ON public.gmail_submissions FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admin submissions update/delete" ON public.gmail_submissions FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin submissions delete" ON public.gmail_submissions FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- withdrawals
CREATE POLICY "own withdrawals read" ON public.withdrawals FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "own withdrawals insert" ON public.withdrawals FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);
CREATE POLICY "admin withdrawals update" ON public.withdrawals FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "admin withdrawals delete" ON public.withdrawals FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- transactions
CREATE POLICY "read own tx" ON public.transactions FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'));

-- notifications
CREATE POLICY "read own notif" ON public.notifications FOR SELECT TO authenticated
USING (auth.uid() = user_id);
CREATE POLICY "update own notif" ON public.notifications FOR UPDATE TO authenticated
USING (auth.uid() = user_id);

-- settings / features / cms_pages: readable by everyone; admin writes only via service role
CREATE POLICY "public settings read" ON public.settings FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin settings all" ON public.settings FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "public features read" ON public.features FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin features all" ON public.features FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "public cms read" ON public.cms_pages FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin cms all" ON public.cms_pages FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- audit_logs
CREATE POLICY "admin audit read" ON public.audit_logs FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

-- ============ TRIGGERS ============
-- helper: update_updated_at_column
CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- new user handler
CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uname TEXT;
BEGIN
  uname := COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1));
  -- ensure unique username
  IF EXISTS (SELECT 1 FROM public.profiles WHERE username = uname) THEN
    uname := uname || '_' || substr(NEW.id::text, 1, 6);
  END IF;
  INSERT INTO public.profiles (id, username, full_name, email)
  VALUES (NEW.id, uname, COALESCE(NEW.raw_user_meta_data->>'full_name', uname), NEW.email);
  INSERT INTO public.balances (user_id) VALUES (NEW.id);
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- gmail submission status change trigger
CREATE OR REPLACE FUNCTION public.on_gmail_status_change() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  new_balance NUMERIC(14,2);
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF NEW.status = 'approved' THEN
    UPDATE public.balances SET balance = balance + NEW.price, updated_at = now()
      WHERE user_id = NEW.user_id RETURNING balance INTO new_balance;
    INSERT INTO public.transactions (user_id, type, amount, balance_after, description, ref_id)
      VALUES (NEW.user_id, 'gmail_reward', NEW.price, new_balance, 'Gmail disetujui: ' || NEW.gmail, NEW.id);
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'gmail_approved', 'Gmail Disetujui', 'Gmail ' || NEW.gmail || ' disetujui. Saldo +Rp' || NEW.price::text);
  ELSIF NEW.status = 'rejected' THEN
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'gmail_rejected', 'Gmail Ditolak', 'Gmail ' || NEW.gmail || ' ditolak.');
  END IF;
  NEW.reviewed_at := now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_gmail_status BEFORE UPDATE ON public.gmail_submissions
FOR EACH ROW EXECUTE FUNCTION public.on_gmail_status_change();

-- withdrawal status change trigger
CREATE OR REPLACE FUNCTION public.on_withdrawal_status_change() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  new_balance NUMERIC(14,2);
  cur_balance NUMERIC(14,2);
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF NEW.status = 'approved' THEN
    SELECT balance INTO cur_balance FROM public.balances WHERE user_id = NEW.user_id FOR UPDATE;
    IF cur_balance < NEW.amount THEN
      RAISE EXCEPTION 'Saldo user tidak cukup untuk penarikan ini';
    END IF;
    UPDATE public.balances
      SET balance = balance - NEW.amount,
          total_withdrawn = total_withdrawn + NEW.amount,
          updated_at = now()
      WHERE user_id = NEW.user_id RETURNING balance INTO new_balance;
    INSERT INTO public.transactions (user_id, type, amount, balance_after, description, ref_id)
      VALUES (NEW.user_id, 'withdrawal', -NEW.amount, new_balance,
        'Penarikan ' || NEW.method::text || ' ke ' || NEW.account_number, NEW.id);
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'withdrawal_approved', 'Penarikan Disetujui',
        'Penarikan Rp' || NEW.amount::text || ' via ' || NEW.method::text || ' berhasil.');
  ELSIF NEW.status = 'rejected' THEN
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'withdrawal_rejected', 'Penarikan Ditolak',
        'Penarikan Rp' || NEW.amount::text || ' via ' || NEW.method::text || ' ditolak.');
  END IF;
  NEW.reviewed_at := now();
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_withdrawal_status BEFORE UPDATE ON public.withdrawals
FOR EACH ROW EXECUTE FUNCTION public.on_withdrawal_status_change();

-- ============ SEED SETTINGS & PAGES ============
INSERT INTO public.settings (key, value) VALUES
  ('site_name', '"HANZGMAIL.ID"'),
  ('site_tagline', '"Kirim Gmail, Cuan Setiap Hari"'),
  ('gmail_price', '5000'),
  ('gmail_suffix', '"8372"'),
  ('whatsapp_admin', '"628123456789"'),
  ('telegram_link', '"https://t.me/hanzgmail"'),
  ('banner_text', '"Selamat datang di HANZGMAIL.ID — Platform kirim Gmail terpercaya."'),
  ('announcement', '"Harga per Gmail: Rp5.000 — Wajib akhiran 8372"');

INSERT INTO public.cms_pages (slug, title, content) VALUES
  ('bantuan', 'Pusat Bantuan', 'Hubungi admin melalui WhatsApp atau Telegram untuk bantuan.'),
  ('faq', 'FAQ', 'Q: Berapa harga per Gmail? A: Rp5.000. Q: Syarat? Gmail wajib akhiran 8372 dan aktif.'),
  ('syarat', 'Syarat & Ketentuan', 'Dengan menggunakan website ini Anda setuju dengan syarat berlaku.'),
  ('privasi', 'Kebijakan Privasi', 'Kami menghormati privasi Anda.');

INSERT INTO public.features (name, description, icon, color, href, sort_order) VALUES
  ('Kirim Gmail', 'Kirim Gmail berakhiran 8372 dan dapatkan Rp5.000 per Gmail disetujui.', 'Mail', '#3b82f6', '/kirim', 1),
  ('Saldo', 'Lihat total saldo dan riwayat transaksi.', 'Wallet', '#0ea5e9', '/saldo', 2),
  ('Penarikan', 'Tarik saldo via DANA atau GoPay.', 'ArrowDownToLine', '#22c55e', '/penarikan', 3),
  ('Leaderboard', 'Papan peringkat pengguna teraktif.', 'Trophy', '#f59e0b', '/leaderboard', 4),
  ('Riwayat', 'Riwayat pengiriman Gmail Anda.', 'History', '#6366f1', '/riwayat', 5),
  ('Notifikasi', 'Notifikasi terbaru untuk akun Anda.', 'Bell', '#ec4899', '/notifikasi', 6);
