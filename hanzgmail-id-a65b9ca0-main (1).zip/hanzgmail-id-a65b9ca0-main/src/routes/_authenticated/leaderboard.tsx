import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Trophy, Medal, Award } from "lucide-react";

export const Route = createFileRoute("/_authenticated/leaderboard")({
  head: () => ({ meta: [{ title: "Leaderboard — HANZGMAIL.ID" }] }),
  component: LB,
});

function LB() {
  const { data } = useQuery({
    queryKey: ["leaderboard-full"],
    queryFn: async () => {
      const { data: profiles } = await supabase.from("profiles").select("id, username").limit(200);
      if (!profiles) return [];
      const rows = await Promise.all(
        profiles.map(async (p) => {
          const { count } = await supabase
            .from("gmail_submissions")
            .select("*", { count: "exact", head: true })
            .eq("user_id", p.id)
            .eq("status", "approved");
          return { username: p.username, count: count ?? 0 };
        }),
      );
      return rows.filter((r) => r.count > 0).sort((a, b) => b.count - a.count);
    },
  });

  const podium = data?.slice(0, 3) ?? [];
  const rest = data?.slice(3) ?? [];

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Leaderboard</h1>
        <p className="text-sm text-muted-foreground">Peringkat pengguna berdasarkan Gmail disetujui</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        {podium.map((r, i) => {
          const meta = [
            { icon: Trophy, cls: "from-warning to-warning/50 text-warning", label: "Juara 1" },
            { icon: Medal, cls: "from-muted-foreground/80 to-muted-foreground/40 text-muted-foreground", label: "Juara 2" },
            { icon: Award, cls: "from-warning/60 to-warning/20 text-warning/80", label: "Juara 3" },
          ][i];
          const Icon = meta.icon;
          return (
            <Card key={r.username} className="p-5 card-elevated text-center relative overflow-hidden">
              <div className={`h-12 w-12 mx-auto rounded-full bg-gradient-to-br ${meta.cls} bg-opacity-20 flex items-center justify-center`}>
                <Icon className="h-6 w-6" />
              </div>
              <p className="mt-3 text-xs uppercase tracking-wider text-muted-foreground">{meta.label}</p>
              <p className="font-display font-bold text-lg truncate">{r.username}</p>
              <p className="text-sm text-muted-foreground">{r.count} Gmail disetujui</p>
            </Card>
          );
        })}
      </div>

      <Card className="p-5 card-elevated">
        <h3 className="font-display font-semibold mb-3">Peringkat Lainnya</h3>
        <div className="divide-y">
          {rest.map((r, i) => (
            <div key={r.username} className="flex items-center justify-between py-2.5 text-sm">
              <div className="flex items-center gap-3">
                <span className="h-7 w-7 rounded-full bg-muted flex items-center justify-center text-xs font-semibold">
                  {i + 4}
                </span>
                <span>{r.username}</span>
              </div>
              <span className="font-semibold">{r.count}</span>
            </div>
          ))}
          {!rest.length && <p className="text-xs text-muted-foreground py-2">Belum ada data</p>}
        </div>
      </Card>
    </div>
  );
}
