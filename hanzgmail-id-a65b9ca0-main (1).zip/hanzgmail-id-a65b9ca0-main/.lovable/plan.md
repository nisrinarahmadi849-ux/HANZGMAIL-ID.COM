# HANZGMAIL — Penyesuaian ke Spesifikasi Premium Lengkap

Fondasi sudah jalan (auth, DB, trigger, dashboard, kirim, saldo, penarikan, leaderboard, riwayat, notifikasi, admin approve). Rencana ini menutup gap antara implementasi saat ini dan spec baru.

## Ringkasan Perubahan

### 1. Branding & Pengaturan
- Rename `HANZGMAIL.ID` → `HANZGMAIL` di semua `head()`, landing, sidebar, footer.
- Tambah setting baru: `required_password` (default `FINEIRGA`), `max_gmail_per_submit` (10), `max_withdrawal` (5000), `min_withdrawal`, `discord_link`, `site_status` (aktif/maintenance), `rules_text`, `banner_image`, `logo_url`, `primary_color`.
- Update `/admin/pengaturan` untuk menampilkan semua field baru.

### 2. Dashboard User — Hero Saldo + 4 Menu Card
- Ganti grid stats kecil dengan **Hero Card Saldo** besar: ikon Wallet, angka saldo dengan animasi count-up, tombol "Tarik Saldo" + "Refresh".
- Di bawahnya, 4 card premium hover-animated: **Rules**, **Leaderboard**, **Saluran**, **Penarikan**.
- Kartu status Gmail (Pending/Disetujui/Ditolak) tetap ditampilkan sebagai row kecil.
- Grafik 7 hari dipindah ke bagian bawah.

### 3. Halaman Baru
- `/rules` — tampilkan `settings.rules_text` (markdown/plain), tombol edit hanya untuk admin (link ke pengaturan).
- `/saluran` — tombol WhatsApp / Telegram / Discord dari settings.

### 4. Stor Gmail — Batch + Password Wajib
- Rombak `/kirim`: form dinamis hingga 10 baris (Gmail, Password, Catatan).
- Validasi client: setiap gmail berakhiran `8372`, setiap password === `settings.required_password` (case-sensitive), tidak boleh duplikat dalam batch, tidak boleh sudah ada di DB milik user tsb.
- Submit → insert banyak `gmail_submissions` sekaligus, semua status `pending`.
- Tambah kolom `password` (text, terenkripsi via RLS — hanya user pemilik & admin bisa baca) dan `note` di `gmail_submissions` (migration).

### 5. Penarikan — Field & Batas
- Tambah field **Nama Pemilik** di form + kolom `account_name` di `withdrawals` (migration).
- Validasi nominal: `>= min_withdrawal` dan `<= max_withdrawal` dari settings (default max 5000).
- Tampilkan info batas di form.

### 6. Alasan Penolakan & Notifikasi
- Tambah kolom `admin_note` di `gmail_submissions` dan `withdrawals` (migration).
- Update trigger `on_gmail_status_change` & `on_withdrawal_status_change` agar notifikasi menyertakan `admin_note` saat rejected.
- Admin panel: dialog "Tolak" dengan textarea alasan → menulis `admin_note` sebelum update status.
- Riwayat user menampilkan `admin_note` di baris ditolak.

### 7. Verifikasi Akun
- Tambah kolom `verified` boolean di `profiles` (migration, default false).
- Admin users page: tombol Verifikasi / Batalkan Verifikasi.
- Badge "Verified" di profil, leaderboard, dan riwayat.
- Notifikasi otomatis saat diverifikasi (trigger di `profiles`).

### 8. Suspend & Reset Password (Admin)
- Kolom `status` di `profiles` sudah ada; pastikan admin bisa suspend/aktifkan (sudah ada) + tambah tombol **Reset Password** (kirim email reset via `resetPasswordForEmail` server fn).
- Blokir login user `suspended` (cek di `/auth` + di `_authenticated` guard).

### 9. Site Status (Maintenance Mode)
- Bila `settings.site_status = 'maintenance'`, semua route non-admin menampilkan halaman maintenance.

### 10. CMS Lanjutan
- Tambah section di `/admin/pengaturan`: upload logo, banner dashboard, edit rules_text (textarea besar), warna primary (color picker → simpan ke `settings.primary_color`, di-inject via CSS var di `__root`).

### 11. Polish UI
- Animasi count-up pada saldo (custom hook).
- Hover lift + glow di 4 menu card.
- Loading skeleton di dashboard & tabel.

## Detail Teknis (Ringkas)

**Migrasi DB (satu file)**:
- `ALTER TABLE gmail_submissions ADD COLUMN password text, ADD COLUMN note text, ADD COLUMN admin_note text;`
- `ALTER TABLE withdrawals ADD COLUMN account_name text, ADD COLUMN admin_note text;`
- `ALTER TABLE profiles ADD COLUMN verified boolean DEFAULT false;`
- Update fungsi trigger status change untuk menyertakan `admin_note` di pesan notifikasi.
- Trigger baru `on_profile_verified` → insert notifikasi.
- Seed settings baru (`required_password=FINEIRGA`, `max_gmail_per_submit=10`, `max_withdrawal=5000`, `min_withdrawal=1000`, `discord_link=''`, `site_status='active'`, `rules_text=<default>`).

**File yang berubah/baru**:
- Migration (1 file baru).
- `src/routes/_authenticated/dashboard.tsx` (redesign hero + 4 card).
- `src/routes/_authenticated/kirim.tsx` (batch + password wajib).
- `src/routes/_authenticated/penarikan.tsx` (nama pemilik + batas).
- `src/routes/_authenticated/rules.tsx` (baru).
- `src/routes/_authenticated/saluran.tsx` (baru).
- `src/routes/_authenticated/profil.tsx` (badge verified, tombol admin reset).
- `src/routes/_authenticated/riwayat.tsx` (kolom catatan admin).
- `src/routes/_authenticated/admin/pengaturan.tsx` (semua setting baru + upload).
- `src/routes/_authenticated/admin/gmail.tsx` (dialog tolak dgn alasan).
- `src/routes/_authenticated/admin/penarikan.tsx` (dialog tolak dgn alasan).
- `src/routes/_authenticated/admin/users.tsx` (verify + reset password).
- `src/routes/__root.tsx` (inject primary_color, cek site_status).
- `src/components/app-sidebar.tsx` (link Rules & Saluran, rename brand).
- `src/hooks/use-count-up.ts` (baru).

## Catatan
- Password gmail disimpan plaintext di DB (dibutuhkan admin untuk cek); dilindungi RLS ketat (hanya pemilik & admin). Bila Anda ingin di-hash/enkripsi, beri tahu — akan mengubah alur.
- Ganti nama brand: konfirmasi apakah domain juga jadi `hanzgmail.lovable.app` (hanya UI/branding — publish/domain diurus terpisah).

Setuju? Bila ada bagian yang tidak perlu (mis. maintenance mode, upload logo), beri tahu agar saya skip.
