import { createFileRoute, Outlet, redirect, Link, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Shield, LayoutDashboard, Users, Mail, ArrowDownToLine, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  beforeLoad: async () => {
    const { data: u } = await supabase.auth.getUser();
    if (!u.user) throw redirect({ to: "/auth" });
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", u.user.id)
      .eq("role", "admin")
      .maybeSingle();
    if (!data) throw redirect({ to: "/dashboard" });
  },
  component: AdminLayout,
});

const nav: { to: "/admin" | "/admin/users" | "/admin/gmail" | "/admin/penarikan" | "/admin/pengaturan"; label: string; icon: typeof LayoutDashboard; exact?: boolean }[] = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/users", label: "Users", icon: Users },
  { to: "/admin/gmail", label: "Gmail", icon: Mail },
  { to: "/admin/penarikan", label: "Penarikan", icon: ArrowDownToLine },
  { to: "/admin/pengaturan", label: "Pengaturan", icon: Settings },
];

function AdminLayout() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
          <Shield className="h-4 w-4" />
        </div>
        <div>
          <h1 className="font-display font-bold text-xl">Panel Admin</h1>
          <p className="text-xs text-muted-foreground">Kelola pengguna, transaksi, dan pengaturan</p>
        </div>
      </div>

      <div className="flex gap-1 overflow-x-auto border-b -mx-4 px-4 sm:mx-0 sm:px-0">
        {nav.map((n) => {
          const active = n.exact ? pathname === n.to : pathname.startsWith(n.to);
          return (
            <Link
              key={n.to}
              to={n.to}
              className={cn(
                "flex items-center gap-1.5 px-3 py-2 text-sm border-b-2 -mb-px whitespace-nowrap transition-colors",
                active
                  ? "border-primary text-foreground font-semibold"
                  : "border-transparent text-muted-foreground hover:text-foreground",
              )}
            >
              <n.icon className="h-4 w-4" />
              {n.label}
            </Link>
          );
        })}
      </div>

      <Outlet />
    </div>
  );
}
