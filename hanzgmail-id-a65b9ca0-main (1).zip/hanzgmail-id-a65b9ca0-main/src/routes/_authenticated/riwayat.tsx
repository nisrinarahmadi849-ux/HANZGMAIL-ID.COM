import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/status-badge";
import { rupiah, formatDate } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

export const Route = createFileRoute("/_authenticated/riwayat")({
  head: () => ({ meta: [{ title: "Riwayat — HANZGMAIL" }] }),
  component: Riwayat,
});

const PAGE = 15;

function Riwayat() {
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<string>("all");

  const { data } = useQuery({
    queryKey: ["riwayat", page, q, status],
    queryFn: async () => {
      let query = supabase
        .from("gmail_submissions")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(page * PAGE, page * PAGE + PAGE - 1);
      if (status !== "all") query = query.eq("status", status as "pending" | "approved" | "rejected");
      if (q) query = query.ilike("gmail", `%${q}%`);
      const { data, count } = await query;
      return { rows: data ?? [], count: count ?? 0 };
    },
  });

  const total = data?.count ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Riwayat Pengiriman</h1>
        <p className="text-sm text-muted-foreground">Semua Gmail yang pernah Anda kirim</p>
      </div>

      <Card className="p-4 card-elevated">
        <div className="flex flex-wrap gap-2 mb-3">
          <div className="relative flex-1 min-w-56">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Cari gmail..." className="pl-8" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
          </div>
          <Select value={status} onValueChange={(v) => { setStatus(v); setPage(0); }}>
            <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Disetujui</SelectItem>
              <SelectItem value="rejected">Ditolak</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tanggal</TableHead>
                <TableHead>Gmail</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Catatan Admin</TableHead>
                <TableHead className="text-right">Harga</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data?.rows.map((r) => (
                <TableRow key={r.id}>
                  <TableCell className="text-xs text-muted-foreground">{formatDate(r.created_at)}</TableCell>
                  <TableCell className="font-medium">{r.gmail}</TableCell>
                  <TableCell><StatusBadge status={r.status} /></TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-[240px] truncate">
                    {r.status === "rejected" ? (r.admin_note || "-") : "-"}
                  </TableCell>
                  <TableCell className="text-right font-semibold">{rupiah(r.price)}</TableCell>
                </TableRow>
              ))}
              {!data?.rows.length && (
                <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-6">Tidak ada data</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        <div className="flex items-center justify-between mt-3 text-sm">
          <span className="text-muted-foreground">Total: {total}</span>
          <div className="flex gap-1">
            <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}>Prev</Button>
            <span className="px-3 py-1">{page + 1} / {pages}</span>
            <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1}>Next</Button>
          </div>
        </div>
      </Card>
    </div>
  );
}
