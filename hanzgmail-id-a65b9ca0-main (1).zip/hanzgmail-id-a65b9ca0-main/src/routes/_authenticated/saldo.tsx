import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { rupiah, formatDate } from "@/lib/format";
import { Wallet, ArrowDownToLine, TrendingUp } from "lucide-react";

export const Route = createFileRoute("/_authenticated/saldo")({
  head: () => ({ meta: [{ title: "Saldo — HANZGMAIL.ID" }] }),
  component: SaldoPage,
});

function SaldoPage() {
  const { data } = useQuery({
    queryKey: ["saldo-page"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user!.id;
      const [balance, tx] = await Promise.all([
        supabase.from("balances").select("*").eq("user_id", uid).maybeSingle(),
        supabase.from("transactions").select("*").eq("user_id", uid).order("created_at", { ascending: false }).limit(50),
      ]);
      return {
        balance: Number(balance.data?.balance ?? 0),
        withdrawn: Number(balance.data?.total_withdrawn ?? 0),
        tx: tx.data ?? [],
      };
    },
  });

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">Saldo</h1>
          <p className="text-sm text-muted-foreground">Kelola saldo dan riwayat transaksi</p>
        </div>
        <Button asChild>
          <Link to="/penarikan">
            <ArrowDownToLine className="mr-1 h-4 w-4" /> Tarik Saldo
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Card className="p-6 card-elevated relative overflow-hidden">
          <div
            className="absolute inset-0 opacity-30 pointer-events-none"
            style={{ background: "var(--gradient-primary)" }}
          />
          <div className="relative">
            <div className="flex items-center gap-2 text-primary-foreground/80">
              <Wallet className="h-4 w-4" />
              <span className="text-xs uppercase tracking-wider">Total Saldo</span>
            </div>
            <p className="mt-3 text-3xl font-display font-bold text-primary-foreground">
              {rupiah(data?.balance ?? 0)}
            </p>
          </div>
        </Card>
        <Card className="p-6 card-elevated">
          <div className="flex items-center gap-2 text-muted-foreground">
            <TrendingUp className="h-4 w-4" />
            <span className="text-xs uppercase tracking-wider">Total Penarikan</span>
          </div>
          <p className="mt-3 text-3xl font-display font-bold">{rupiah(data?.withdrawn ?? 0)}</p>
        </Card>
      </div>

      <Card className="p-5 card-elevated">
        <h3 className="font-display font-semibold mb-3">Riwayat Transaksi</h3>
        <div className="divide-y">
          {data?.tx.map((t) => (
            <div key={t.id} className="flex items-center justify-between py-2.5 text-sm gap-3">
              <div className="min-w-0">
                <p className="font-medium truncate">{t.description}</p>
                <p className="text-xs text-muted-foreground">{formatDate(t.created_at)}</p>
              </div>
              <div className="text-right shrink-0">
                <p className={`font-semibold ${Number(t.amount) < 0 ? "text-destructive" : "text-success"}`}>
                  {Number(t.amount) < 0 ? "-" : "+"}
                  {rupiah(Math.abs(Number(t.amount)))}
                </p>
                <p className="text-xs text-muted-foreground">Saldo: {rupiah(t.balance_after)}</p>
              </div>
            </div>
          ))}
          {!data?.tx.length && <p className="text-xs text-muted-foreground py-4">Belum ada transaksi</p>}
        </div>
      </Card>
    </div>
  );
}
