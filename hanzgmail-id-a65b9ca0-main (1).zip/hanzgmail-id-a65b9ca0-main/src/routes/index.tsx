import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Mail, Wallet, Trophy, ShieldCheck, ArrowRight, Sparkles } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "HANZGMAIL — Stor Gmail, Cuan Setiap Hari" },
      {
        name: "description",
        content:
          "Stor Gmail berakhiran 8372, dapatkan saldo per Gmail disetujui. Tarik saldo via DANA & GoPay.",
      },
      { property: "og:title", content: "HANZGMAIL — Stor Gmail, Cuan Setiap Hari" },
      { property: "og:description", content: "Stor Gmail berakhiran 8372, dapatkan saldo per Gmail disetujui. Tarik saldo via DANA & GoPay." },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-40 border-b bg-background/70 backdrop-blur-xl">
        <div className="mx-auto max-w-6xl px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-lg bg-[image:var(--gradient-primary)] flex items-center justify-center text-primary-foreground font-bold">
              H
            </div>
            <span className="font-display font-bold">HANZGMAIL</span>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" asChild>
              <Link to="/auth">Login</Link>
            </Button>
            <Button asChild>
              <Link to="/auth">Daftar</Link>
            </Button>
          </div>
        </div>
      </nav>

      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 opacity-40 pointer-events-none"
          style={{
            background:
              "radial-gradient(600px circle at 20% 20%, oklch(0.7 0.18 250 / 0.35), transparent), radial-gradient(600px circle at 80% 40%, oklch(0.55 0.19 255 / 0.25), transparent)",
          }}
        />
        <div className="relative mx-auto max-w-6xl px-4 py-20 sm:py-32 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border bg-card/50 backdrop-blur px-3 py-1 text-xs font-medium mb-6">
            <Sparkles className="h-3 w-3 text-primary" />
            Platform Stor Gmail Premium
          </div>
          <h1 className="text-4xl sm:text-6xl font-display font-bold tracking-tight">
            Stor Gmail. <span className="gradient-text">Cuan Setiap Hari.</span>
          </h1>
          <p className="mt-6 text-base sm:text-lg text-muted-foreground max-w-2xl mx-auto">
            Dapatkan saldo per Gmail berakhiran <code className="rounded bg-muted px-1.5">8372</code>{" "}
            yang disetujui. Cepat, aman, langsung tarik ke DANA atau GoPay.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button size="lg" asChild>
              <Link to="/auth">
                Mulai Sekarang <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link to="/auth">Sudah punya akun?</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-20 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { icon: Mail, title: "Stor Cepat", desc: "Kirim hingga 10 Gmail sekaligus, akhiran 8372." },
          { icon: Wallet, title: "Auto Payout", desc: "Saldo bertambah otomatis setelah disetujui." },
          { icon: Trophy, title: "Leaderboard", desc: "Bersaing menjadi kontributor terbaik." },
          { icon: ShieldCheck, title: "Aman & Terpercaya", desc: "Data terenkripsi, RLS aktif." },
        ].map((f) => (
          <Card key={f.title} className="p-6 card-elevated hover:shadow-[var(--shadow-glow)] transition-shadow">
            <div className="h-11 w-11 rounded-lg bg-primary/10 text-primary flex items-center justify-center mb-4">
              <f.icon className="h-5 w-5" />
            </div>
            <h3 className="font-display font-semibold">{f.title}</h3>
            <p className="text-sm text-muted-foreground mt-1">{f.desc}</p>
          </Card>
        ))}
      </section>

      <footer className="border-t py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} HANZGMAIL
      </footer>
    </div>
  );
}
