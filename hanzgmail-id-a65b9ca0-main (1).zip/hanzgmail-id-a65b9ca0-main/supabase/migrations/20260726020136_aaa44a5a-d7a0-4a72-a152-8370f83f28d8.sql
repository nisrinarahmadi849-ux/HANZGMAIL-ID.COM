
-- 1) Profile bank fields
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS bank_method text,
  ADD COLUMN IF NOT EXISTS bank_account_name text,
  ADD COLUMN IF NOT EXISTS bank_account_number text;

-- 2) New settings seeds
INSERT INTO public.settings (key, value) VALUES
  ('withdrawal_open', 'true'::jsonb),
  ('developer_whatsapp', '""'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- 3) Enforce server-controlled defaults on gmail_submissions inserts
CREATE OR REPLACE FUNCTION public.set_gmail_submission_defaults()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  NEW.status := 'pending';
  NEW.price := COALESCE(
    (SELECT (value::text)::numeric FROM public.settings WHERE key = 'gmail_price'),
    5000
  );
  NEW.admin_note := NULL;
  NEW.reviewed_at := NULL;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_gmail_submission_defaults ON public.gmail_submissions;
CREATE TRIGGER trg_gmail_submission_defaults
  BEFORE INSERT ON public.gmail_submissions
  FOR EACH ROW EXECUTE FUNCTION public.set_gmail_submission_defaults();

-- 4) Prevent non-admin users from mutating status/verified on their own profile
CREATE OR REPLACE FUNCTION public.guard_profile_self_update()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() = NEW.id AND NOT public.has_role(auth.uid(), 'admin') THEN
    NEW.status := OLD.status;
    NEW.verified := OLD.verified;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_guard_profile_self_update ON public.profiles;
CREATE TRIGGER trg_guard_profile_self_update
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.guard_profile_self_update();
