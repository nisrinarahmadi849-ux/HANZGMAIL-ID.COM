import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatDate } from "@/lib/format";
import { useEffect } from "react";
import { Bell, CheckCheck } from "lucide-react";

export const Route = createFileRoute("/_authenticated/notifikasi")({
  head: () => ({ meta: [{ title: "Notifikasi — HANZGMAIL.ID" }] }),
  component: Notif,
});

function Notif() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["notifications"],
    queryFn: async () => {
      const { data } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(100);
      return data ?? [];
    },
  });

  useEffect(() => {
    // mark all as read on view
    supabase.from("notifications").update({ read: true }).eq("read", false).then(() => {
      qc.invalidateQueries({ queryKey: ["unread-count"] });
    });
  }, [qc]);

  const markAll = async () => {
    await supabase.from("notifications").update({ read: true }).eq("read", false);
    qc.invalidateQueries({ queryKey: ["unread-count"] });
    qc.invalidateQueries({ queryKey: ["notifications"] });
  };

  return (
    <div className="max-w-3xl space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl sm:text-3xl font-display font-bold">Notifikasi</h1>
          <p className="text-sm text-muted-foreground">Update terbaru untuk akun Anda</p>
        </div>
        <Button variant="outline" size="sm" onClick={markAll}>
          <CheckCheck className="h-4 w-4 mr-1" /> Tandai semua
        </Button>
      </div>

      <div className="space-y-2">
        {data?.map((n) => (
          <Card key={n.id} className="p-4 card-elevated flex items-start gap-3">
            <div className="h-9 w-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Bell className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <p className="font-semibold text-sm">{n.title}</p>
                <span className="text-xs text-muted-foreground shrink-0">{formatDate(n.created_at)}</span>
              </div>
              <p className="text-sm text-muted-foreground">{n.message}</p>
            </div>
          </Card>
        ))}
        {!data?.length && <p className="text-sm text-muted-foreground text-center py-8">Belum ada notifikasi</p>}
      </div>
    </div>
  );
}
