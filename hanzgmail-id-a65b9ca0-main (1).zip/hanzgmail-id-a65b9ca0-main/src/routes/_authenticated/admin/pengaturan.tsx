import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin/pengaturan")({
  head: () => ({ meta: [{ title: "Admin Pengaturan — HANZGMAIL" }] }),
  component: AdminSettings,
});

type Field = { key: string; label: string; kind: "text" | "number" | "textarea" | "color" | "toggle" };

const FIELDS: Field[] = [
  { key: "site_name", label: "Nama Website", kind: "text" },
  { key: "site_tagline", label: "Tagline", kind: "text" },
  { key: "logo_url", label: "URL Logo", kind: "text" },
  { key: "banner_image", label: "URL Banner Dashboard", kind: "text" },
  { key: "primary_color", label: "Warna Utama (oklch/hex, opsional)", kind: "text" },
  { key: "site_status", label: "Status Website (active / maintenance)", kind: "text" },
  { key: "gmail_open", label: "Stor Gmail Dibuka? (true / false)", kind: "toggle" },
  { key: "withdrawal_open", label: "Penarikan Dibuka? (true / false)", kind: "toggle" },
  { key: "announcement_1", label: "Pengumuman Berputar #1 (maks 3)", kind: "text" },
  { key: "announcement_2", label: "Pengumuman Berputar #2", kind: "text" },
  { key: "announcement_3", label: "Pengumuman Berputar #3", kind: "text" },
  { key: "announcement", label: "Pengumuman Lama (opsional)", kind: "textarea" },
  { key: "banner_text", label: "Banner Text", kind: "text" },
  { key: "rules_text", label: "Rules", kind: "textarea" },
  { key: "gmail_price", label: "Harga per Gmail", kind: "number" },
  { key: "gmail_suffix", label: "Akhiran Gmail", kind: "text" },
  { key: "required_password", label: "Password Wajib Gmail", kind: "text" },
  { key: "max_gmail_per_submit", label: "Maksimal Gmail per Submit", kind: "number" },
  { key: "daily_submit_limit", label: "Limit Storan per Hari (Dashboard)", kind: "number" },
  { key: "min_withdrawal", label: "Minimal Penarikan", kind: "number" },
  { key: "max_withdrawal", label: "Maksimal Penarikan", kind: "number" },
  { key: "whatsapp_admin", label: "Link/Nomor WhatsApp Admin (Saluran)", kind: "text" },
  { key: "telegram_link", label: "Link Telegram (Saluran)", kind: "text" },
  { key: "discord_link", label: "Link Discord (Saluran)", kind: "text" },
  { key: "developer_whatsapp", label: "Nomor WhatsApp Pengembang (Dashboard)", kind: "text" },
];

function AdminSettings() {
  const qc = useQueryClient();
  const { data } = useQuery({
    queryKey: ["admin-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("settings").select("*");
      return data ?? [];
    },
  });

  const [form, setForm] = useState<Record<string, string>>({});
  useEffect(() => {
    if (data) {
      const m: Record<string, string> = {};
      data.forEach((r) => {
        const v = r.value;
        m[r.key] = typeof v === "string" ? v : typeof v === "number" ? String(v) : JSON.stringify(v);
      });
      setForm(m);
    }
  }, [data]);

  const save = async () => {
    for (const f of FIELDS) {
      const raw = form[f.key] ?? "";
      let value: number | string | boolean = raw;
      if (f.kind === "number") value = Number(raw) || 0;
      else if (f.kind === "toggle") value = raw === "true" || raw === "1" ? "true" : "false";
      const { error } = await supabase.from("settings").upsert({
        key: f.key,
        value,
        updated_at: new Date().toISOString(),
      });
      if (error) return toast.error(f.key + ": " + error.message);
    }
    toast.success("Pengaturan disimpan");
    qc.invalidateQueries({ queryKey: ["admin-settings"] });
    qc.invalidateQueries({ queryKey: ["settings-kirim"] });
    qc.invalidateQueries({ queryKey: ["wd-page"] });
    qc.invalidateQueries({ queryKey: ["rules"] });
    qc.invalidateQueries({ queryKey: ["saluran-settings"] });
    qc.invalidateQueries({ queryKey: ["announcements-marquee"] });
  };

  return (
    <Card className="p-6 card-elevated space-y-4 max-w-3xl">
      <div className="grid gap-4 sm:grid-cols-2">
        {FIELDS.map((f) => (
          <div key={f.key} className={f.kind === "textarea" ? "sm:col-span-2" : ""}>
            <Label htmlFor={f.key}>{f.label}</Label>
            {f.kind === "textarea" ? (
              <Textarea
                id={f.key}
                rows={5}
                value={form[f.key] ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, [f.key]: e.target.value }))}
              />
            ) : f.kind === "toggle" ? (
              <div className="flex items-center gap-3 h-9 mt-1">
                <button
                  type="button"
                  role="switch"
                  aria-checked={form[f.key] === "true"}
                  onClick={() =>
                    setForm((s) => ({ ...s, [f.key]: s[f.key] === "true" ? "false" : "true" }))
                  }
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    form[f.key] === "true" ? "bg-success" : "bg-muted"
                  }`}
                >
                  <span
                    className={`inline-block h-5 w-5 transform rounded-full bg-background shadow transition-transform ${
                      form[f.key] === "true" ? "translate-x-5" : "translate-x-0.5"
                    }`}
                  />
                </button>
                <span className="text-sm text-muted-foreground">
                  {form[f.key] === "true" ? "Dibuka" : "Ditutup"}
                </span>
              </div>
            ) : (
              <Input
                id={f.key}
                type={f.kind === "number" ? "number" : "text"}
                value={form[f.key] ?? ""}
                onChange={(e) => setForm((s) => ({ ...s, [f.key]: e.target.value }))}
              />
            )}
          </div>
        ))}
      </div>
      <Button onClick={save}>Simpan Perubahan</Button>
    </Card>
  );
}
