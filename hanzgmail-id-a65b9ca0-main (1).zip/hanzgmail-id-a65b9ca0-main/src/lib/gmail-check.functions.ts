import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

export const checkGmailAlive = createServerFn({ method: "POST" })
  .inputValidator((data) =>
    z.object({ email: z.string().min(3).max(120) }).parse(data),
  )
  .handler(async ({ data }) => {
    const email = data.email.trim().toLowerCase();
    if (!/^[a-z0-9._%+-]+@gmail\.com$/i.test(email)) {
      return { status: "invalid" as const, note: "Format Gmail tidak valid" };
    }

    try {
      const res = await fetch(
        "https://mail.google.com/mail/gxlu?email=" + encodeURIComponent(email),
        {
          method: "GET",
          redirect: "manual",
          headers: {
            "user-agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
            accept: "*/*",
          },
        },
      );
      const setCookie =
        res.headers.get("set-cookie") ??
        // Some runtimes expose combined headers only via getSetCookie
        (typeof (res.headers as unknown as { getSetCookie?: () => string[] }).getSetCookie === "function"
          ? ((res.headers as unknown as { getSetCookie: () => string[] }).getSetCookie().join("; "))
          : "");

      if (setCookie && /COMPASS=/i.test(setCookie)) {
        return { status: "active" as const, note: "Akun terdeteksi aktif" };
      }
      return { status: "inactive" as const, note: "Akun tidak terdeteksi / tidak aktif" };
    } catch (e) {
      return {
        status: "unknown" as const,
        note: "Gagal mengecek: " + (e instanceof Error ? e.message : "network error"),
      };
    }
  });
