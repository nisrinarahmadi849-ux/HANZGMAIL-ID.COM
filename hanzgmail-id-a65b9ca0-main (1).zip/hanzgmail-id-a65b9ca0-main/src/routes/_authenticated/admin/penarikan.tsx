import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/status-badge";
import { rupiah, formatDate } from "@/lib/format";
import { Check, X, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/admin/penarikan")({
  head: () => ({ meta: [{ title: "Admin Penarikan — HANZGMAIL" }] }),
  component: AdminWD,
});

const PAGE = 20;
type Row = {
  id: string;
  created_at: string;
  user_id: string;
  method: "dana" | "gopay";
  account_number: string;
  account_name: string | null;
  admin_note: string | null;
  amount: number;
  status: "pending" | "approved" | "rejected";
  username: string;
};

function AdminWD() {
  const qc = useQueryClient();
  const [page, setPage] = useState(0);
  const [status, setStatus] = useState("all");
  const [rejectRow, setRejectRow] = useState<Row | null>(null);
  const [rejectNote, setRejectNote] = useState("");

  const { data } = useQuery({
    queryKey: ["admin-wd", page, status],
    queryFn: async () => {
      let query = supabase
        .from("withdrawals")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(page * PAGE, page * PAGE + PAGE - 1);
      if (status !== "all") query = query.eq("status", status as "pending" | "approved" | "rejected");
      const { data, count } = await query;
      const ids = Array.from(new Set((data ?? []).map((d) => d.user_id)));
      const { data: profs } = ids.length
        ? await supabase.from("profiles").select("id, username").in("id", ids)
        : { data: [] as { id: string; username: string }[] };
      const nameMap = new Map((profs ?? []).map((p) => [p.id, p.username]));
      const rows: Row[] = (data ?? []).map((r) => ({ ...r, username: nameMap.get(r.user_id) ?? "-" }));
      return { rows, count: count ?? 0 };
    },
  });

  const approve = async (id: string) => {
    const { error } = await supabase.from("withdrawals").update({ status: "approved" }).eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Penarikan disetujui");
      qc.invalidateQueries({ queryKey: ["admin-wd"] });
      qc.invalidateQueries({ queryKey: ["admin-dash"] });
    }
  };
  const doReject = async () => {
    if (!rejectRow) return;
    const { error } = await supabase
      .from("withdrawals")
      .update({ status: "rejected", admin_note: rejectNote.trim() || null })
      .eq("id", rejectRow.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Penarikan ditolak");
      setRejectRow(null);
      setRejectNote("");
      qc.invalidateQueries({ queryKey: ["admin-wd"] });
    }
  };
  const del = async (id: string) => {
    if (!confirm("Hapus data ini?")) return;
    const { error } = await supabase.from("withdrawals").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Dihapus");
      qc.invalidateQueries({ queryKey: ["admin-wd"] });
    }
  };

  const total = data?.count ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <Card className="p-4 card-elevated">
      <div className="flex flex-wrap gap-2 mb-3">
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(0); }}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Disetujui</SelectItem>
            <SelectItem value="rejected">Ditolak</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tanggal</TableHead>
              <TableHead>Username</TableHead>
              <TableHead>Metode</TableHead>
              <TableHead>Nama</TableHead>
              <TableHead>Nomor</TableHead>
              <TableHead>Nominal</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data?.rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatDate(r.created_at)}</TableCell>
                <TableCell>{r.username}</TableCell>
                <TableCell className="uppercase">{r.method}</TableCell>
                <TableCell>{r.account_name ?? "-"}</TableCell>
                <TableCell>{r.account_number}</TableCell>
                <TableCell className="font-semibold">{rupiah(r.amount)}</TableCell>
                <TableCell><StatusBadge status={r.status} /></TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  {r.status === "pending" && (
                    <>
                      <Button size="icon" variant="ghost" onClick={() => approve(r.id)}>
                        <Check className="h-4 w-4 text-success" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => { setRejectRow(r); setRejectNote(""); }}>
                        <X className="h-4 w-4 text-destructive" />
                      </Button>
                    </>
                  )}
                  <Button size="icon" variant="ghost" onClick={() => del(r.id)}>
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {!data?.rows.length && (
              <TableRow><TableCell colSpan={8} className="text-center text-muted-foreground py-6">Tidak ada data</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-between mt-3 text-sm">
        <span className="text-muted-foreground">Total: {total}</span>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}>Prev</Button>
          <span className="px-3 py-1">{page + 1} / {pages}</span>
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1}>Next</Button>
        </div>
      </div>

      <Dialog open={!!rejectRow} onOpenChange={(o) => !o && setRejectRow(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tolak Penarikan</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">
              {rejectRow?.method.toUpperCase()} · {rejectRow?.account_number} · <strong>{rupiah(rejectRow?.amount ?? 0)}</strong>
            </p>
            <div>
              <Label htmlFor="rn">Alasan penolakan</Label>
              <Textarea id="rn" value={rejectNote} onChange={(e) => setRejectNote(e.target.value)} placeholder="Contoh: Nomor tujuan tidak sesuai" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectRow(null)}>Batal</Button>
            <Button variant="destructive" onClick={doReject}>Tolak</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
