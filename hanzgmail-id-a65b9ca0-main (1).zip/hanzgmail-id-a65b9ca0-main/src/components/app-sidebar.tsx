import { Link, useRouterState } from "@tanstack/react-router";
import * as React from "react";
import {
  LayoutDashboard,
  Mail,
  Wallet,
  ArrowDownToLine,
  Trophy,
  History,
  Bell,
  User,
  Shield,
  ScrollText,
  Megaphone,
  Menu,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import { useIsAdmin } from "@/hooks/use-auth";

const items = [
  { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard },
  { title: "Stor Gmail", url: "/kirim", icon: Mail },
  { title: "Saldo", url: "/saldo", icon: Wallet },
  { title: "Penarikan", url: "/penarikan", icon: ArrowDownToLine },
  { title: "Rules", url: "/rules", icon: ScrollText },
  { title: "Leaderboard", url: "/leaderboard", icon: Trophy },
  { title: "Saluran", url: "/saluran", icon: Megaphone },
  { title: "Riwayat", url: "/riwayat", icon: History },
  { title: "Notifikasi", url: "/notifikasi", icon: Bell },
  { title: "Profil", url: "/profil", icon: User },
] as const;

export function AppSidebar() {
  const pathname = useRouterState({ select: (r) => r.location.pathname });
  const isAdmin = useIsAdmin();
  const { isMobile, setOpenMobile } = useSidebar();
  const activeRef = React.useRef<HTMLAnchorElement | null>(null);

  const handleNav = React.useCallback(() => {
    if (isMobile) setOpenMobile(false);
  }, [isMobile, setOpenMobile]);

  React.useEffect(() => {
    // Auto-scroll the active menu item into view
    activeRef.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [pathname]);

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b">
        <div className="flex items-center gap-2 px-2 py-3">
          <div className="h-9 w-9 rounded-lg bg-[image:var(--gradient-primary)] flex items-center justify-center text-primary-foreground">
            <Menu className="h-4 w-4" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-sm">Menu</span>
            <span className="text-[10px] text-muted-foreground">HANZGMAIL</span>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigasi</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => {
                const active = pathname === item.url;
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={active}>
                      <Link
                        to={item.url}
                        onClick={handleNav}
                        ref={active ? activeRef : undefined}
                      >
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Admin</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                <SidebarMenuItem>
                  <SidebarMenuButton asChild isActive={pathname.startsWith("/admin")}>
                    <Link to="/admin" onClick={handleNav}>
                      <Shield className="h-4 w-4" />
                      <span>Panel Admin</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>
    </Sidebar>
  );
}
