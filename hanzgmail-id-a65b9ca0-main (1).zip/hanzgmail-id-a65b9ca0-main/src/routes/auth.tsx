import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { toast } from "sonner";
import { z } from "zod";
import { Sparkles, ShieldCheck, Wallet } from "lucide-react";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Masuk / Daftar — HANZGMAIL.ID" },
      { name: "description", content: "Masuk atau daftar akun HANZGMAIL.ID." },
    ],
  }),
  component: AuthPage,
});

const emailSchema = z.string().trim().email("Email tidak valid").max(255);
const passwordSchema = z.string().min(8, "Password minimal 8 karakter").max(72);
const usernameSchema = z
  .string()
  .trim()
  .min(3, "Username minimal 3 karakter")
  .max(24, "Maks 24 karakter")
  .regex(/^[a-zA-Z0-9_]+$/, "Hanya huruf, angka, dan _");

function AuthPage() {
  const router = useRouter();
  const [tab, setTab] = useState<"login" | "register" | "forgot">("login");

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) router.navigate({ to: "/dashboard", replace: true });
    });
  }, [router]);

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background relative overflow-hidden">
      {/* Ambient gradient */}
      <div
        className="absolute inset-0 opacity-50 pointer-events-none"
        style={{
          background:
            "radial-gradient(600px circle at 15% 20%, oklch(0.55 0.19 255 / 0.35), transparent), radial-gradient(700px circle at 85% 80%, oklch(0.7 0.18 240 / 0.25), transparent)",
        }}
      />

      {/* Left hero panel */}
      <div className="relative hidden lg:flex flex-col justify-between p-12 text-primary-foreground overflow-hidden">
        <div
          className="absolute inset-0"
          style={{ background: "var(--gradient-primary)" }}
        />
        <div className="relative">
          <Link to="/" className="inline-flex items-center gap-2">
            <div className="h-11 w-11 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center font-bold text-xl">
              H
            </div>
            <div>
              <p className="font-display font-bold text-lg leading-none">HANZGMAIL.ID</p>
              <p className="text-xs opacity-80">Stor Gmail · Cuan setiap hari</p>
            </div>
          </Link>
        </div>
        <div className="relative space-y-6">
          <h2 className="text-4xl font-display font-bold leading-tight">
            Stor Gmail. <br /> Tarik Saldo. <br /> Semudah itu.
          </h2>
          <div className="space-y-3 text-sm text-primary-foreground/90">
            <div className="flex items-center gap-3">
              <Sparkles className="h-5 w-5" />
              <span>Bayar per Gmail disetujui — instant ke saldo.</span>
            </div>
            <div className="flex items-center gap-3">
              <Wallet className="h-5 w-5" />
              <span>Penarikan via DANA & GoPay tanpa ribet.</span>
            </div>
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5" />
              <span>Aman, transparan, dan real-time.</span>
            </div>
          </div>
        </div>
        <p className="relative text-xs opacity-70">© {new Date().getFullYear()} HANZGMAIL.ID</p>
      </div>

      {/* Right form panel */}
      <div className="relative flex items-center justify-center p-4 sm:p-8">
        <Card className="w-full max-w-md p-6 sm:p-8 glass card-elevated">
          <div className="text-center mb-6 lg:hidden">
            <Link to="/" className="inline-flex items-center gap-2 mb-3">
              <div className="h-10 w-10 rounded-xl bg-[image:var(--gradient-primary)] flex items-center justify-center text-primary-foreground font-bold text-lg">
                H
              </div>
            </Link>
            <h1 className="font-display font-bold text-2xl">HANZGMAIL.ID</h1>
          </div>
          <div className="mb-6 hidden lg:block">
            <h1 className="font-display font-bold text-2xl">
              {tab === "login" ? "Selamat datang kembali" : tab === "register" ? "Buat akun baru" : "Lupa password?"}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              {tab === "login"
                ? "Masuk untuk melanjutkan stor Gmail Anda."
                : tab === "register"
                  ? "Daftar gratis dan mulai raih cuan."
                  : "Kami akan kirimkan link reset ke email Anda."}
            </p>
          </div>

          <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
            <TabsList className="grid grid-cols-3 w-full">
              <TabsTrigger value="login">Login</TabsTrigger>
              <TabsTrigger value="register">Daftar</TabsTrigger>
              <TabsTrigger value="forgot">Lupa</TabsTrigger>
            </TabsList>
            <TabsContent value="login" className="mt-4">
              <LoginForm onDone={() => router.navigate({ to: "/dashboard", replace: true })} />
            </TabsContent>
            <TabsContent value="register" className="mt-4">
              <RegisterForm onDone={() => router.navigate({ to: "/dashboard", replace: true })} />
            </TabsContent>
            <TabsContent value="forgot" className="mt-4">
              <ForgotForm />
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}

function LoginForm({ onDone }: { onDone: () => void }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let email = identifier.trim();
      if (!email.includes("@")) {
        const { data } = await supabase
          .from("profiles")
          .select("email")
          .eq("username", email)
          .maybeSingle();
        if (!data?.email) {
          toast.error("Username/Email atau Password salah.");
          setLoading(false);
          return;
        }
        email = data.email;
      }
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        toast.error("Username/Email atau Password salah.");
      } else {
        toast.success("Login berhasil");
        onDone();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <div>
        <Label htmlFor="id">Username atau Email</Label>
        <Input id="id" value={identifier} onChange={(e) => setIdentifier(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="pw">Password</Label>
        <Input id="pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
      </div>
      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? "Memproses..." : "Masuk"}
      </Button>
    </form>
  );
}

function RegisterForm({ onDone }: { onDone: () => void }) {
  const [username, setUsername] = useState("");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const uv = usernameSchema.safeParse(username);
    if (!uv.success) return toast.error(uv.error.issues[0].message);
    const ev = emailSchema.safeParse(email);
    if (!ev.success) return toast.error(ev.error.issues[0].message);
    const pv = passwordSchema.safeParse(password);
    if (!pv.success) return toast.error(pv.error.issues[0].message);

    setLoading(true);
    try {
      const { data: existing } = await supabase
        .from("profiles")
        .select("id")
        .eq("username", username)
        .maybeSingle();
      if (existing) {
        toast.error("Username sudah digunakan");
        setLoading(false);
        return;
      }
      const { error } = await supabase.auth.signUp({
        email: ev.data,
        password: pv.data,
        options: {
          emailRedirectTo: window.location.origin,
          data: { username: uv.data, full_name: fullName || uv.data },
        },
      });
      if (error) {
        toast.error(error.message);
      } else {
        toast.success("Akun berhasil dibuat");
        onDone();
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label htmlFor="u">Username</Label>
          <Input id="u" value={username} onChange={(e) => setUsername(e.target.value)} required maxLength={24} />
        </div>
        <div>
          <Label htmlFor="fn">Nama Lengkap</Label>
          <Input id="fn" value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={100} />
        </div>
      </div>
      <div>
        <Label htmlFor="em">Email</Label>
        <Input id="em" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </div>
      <div>
        <Label htmlFor="pwr">Password</Label>
        <Input
          id="pwr"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          minLength={8}
        />
      </div>
      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? "Memproses..." : "Buat Akun"}
      </Button>
    </form>
  );
}

function ForgotForm() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.origin + "/reset-password",
    });
    setLoading(false);
    if (error) toast.error(error.message);
    else toast.success("Link reset password telah dikirim ke email Anda.");
  };
  return (
    <form onSubmit={submit} className="space-y-3">
      <p className="text-xs text-muted-foreground">
        Masukkan email Anda. Kami akan kirim link reset password.
      </p>
      <div>
        <Label htmlFor="fe">Email</Label>
        <Input id="fe" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
      </div>
      <Button type="submit" className="w-full" disabled={loading}>
        {loading ? "Memproses..." : "Kirim Link Reset"}
      </Button>
    </form>
  );
}
