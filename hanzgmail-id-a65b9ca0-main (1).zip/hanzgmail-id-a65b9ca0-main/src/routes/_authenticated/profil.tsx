import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { LogOut, ShieldCheck, BadgeCheck, KeyRound } from "lucide-react";
import { useRouter } from "@tanstack/react-router";
import { rupiah } from "@/lib/format";

export const Route = createFileRoute("/_authenticated/profil")({
  head: () => ({ meta: [{ title: "Profil — HANZGMAIL" }] }),
  component: Profil,
});

function Profil() {
  const qc = useQueryClient();
  const router = useRouter();
  const { data } = useQuery({
    queryKey: ["profile"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const uid = u.user!.id;
      const [p, bal, approved, withdrawn, adminCount, myRole] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", uid).maybeSingle(),
        supabase.from("balances").select("balance, total_withdrawn").eq("user_id", uid).maybeSingle(),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("user_id", uid).eq("status", "approved"),
        supabase.from("withdrawals").select("*", { count: "exact", head: true }).eq("user_id", uid).eq("status", "approved"),
        supabase.from("user_roles").select("*", { count: "exact", head: true }).eq("role", "admin"),
        supabase.from("user_roles").select("role").eq("user_id", uid).eq("role", "admin").maybeSingle(),
      ]);
      return {
        profile: p.data,
        balance: Number(bal.data?.balance ?? 0),
        totalWithdrawn: Number(bal.data?.total_withdrawn ?? 0),
        approvedCount: approved.count ?? 0,
        withdrawnCount: withdrawn.count ?? 0,
        adminCount: adminCount.count ?? 0,
        isAdmin: !!myRole.data,
      };
    },
  });

  const [fullName, setFullName] = useState("");
  useEffect(() => {
    if (data?.profile?.full_name) setFullName(data.profile.full_name);
  }, [data]);

  const save = async () => {
    const { error } = await supabase.from("profiles").update({ full_name: fullName }).eq("id", data!.profile!.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Profil disimpan");
      qc.invalidateQueries({ queryKey: ["profile"] });
    }
  };

  const changePassword = async () => {
    if (!data?.profile?.email) return toast.error("Tidak ada email terdaftar");
    const { error } = await supabase.auth.resetPasswordForEmail(data.profile.email, {
      redirectTo: window.location.origin + "/reset-password",
    });
    if (error) toast.error(error.message);
    else toast.success("Link ganti password dikirim ke email Anda");
  };

  const claimAdmin = async () => {
    const { data: u } = await supabase.auth.getUser();
    const { error } = await supabase.from("user_roles").insert({ user_id: u.user!.id, role: "admin" });
    if (error) toast.error(error.message);
    else {
      toast.success("Anda sekarang admin");
      qc.invalidateQueries();
    }
  };

  const signOut = async () => {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    router.navigate({ to: "/auth", replace: true });
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Profil</h1>
        <p className="text-sm text-muted-foreground">Informasi akun Anda</p>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <Card className="p-4 card-elevated">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Saldo</p>
          <p className="mt-2 text-xl font-display font-bold">{rupiah(data?.balance ?? 0)}</p>
        </Card>
        <Card className="p-4 card-elevated">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Gmail Disetujui</p>
          <p className="mt-2 text-xl font-display font-bold">{data?.approvedCount ?? 0}</p>
        </Card>
        <Card className="p-4 card-elevated">
          <p className="text-xs text-muted-foreground uppercase tracking-wider">Total Penarikan</p>
          <p className="mt-2 text-xl font-display font-bold">{rupiah(data?.totalWithdrawn ?? 0)}</p>
        </Card>
      </div>

      <Card className="p-6 card-elevated space-y-4">
        <div className="flex items-center gap-2">
          <h3 className="font-display font-semibold">Informasi Akun</h3>
          {data?.profile?.verified && (
            <span className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-primary/10 text-primary">
              <BadgeCheck className="h-3.5 w-3.5" /> Verified
            </span>
          )}
        </div>
        <div>
          <Label>Username</Label>
          <Input value={data?.profile?.username ?? ""} disabled />
        </div>
        <div>
          <Label>Email</Label>
          <Input value={data?.profile?.email ?? ""} disabled />
        </div>
        <div>
          <Label>Nama Lengkap</Label>
          <Input value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={100} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={save}>Simpan</Button>
          <Button variant="outline" onClick={changePassword}>
            <KeyRound className="h-4 w-4 mr-1" /> Ganti Password
          </Button>
          <Button variant="outline" onClick={signOut}>
            <LogOut className="h-4 w-4 mr-1" /> Logout
          </Button>
        </div>
      </Card>

      {data && data.adminCount === 0 && !data.isAdmin && (
        <Card className="p-6 card-elevated border-primary/40">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <h3 className="font-display font-semibold">Klaim Admin</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Belum ada admin di sistem ini. Klik tombol di bawah untuk menjadi admin pertama.
              </p>
              <Button onClick={claimAdmin}>Jadikan Saya Admin</Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}
