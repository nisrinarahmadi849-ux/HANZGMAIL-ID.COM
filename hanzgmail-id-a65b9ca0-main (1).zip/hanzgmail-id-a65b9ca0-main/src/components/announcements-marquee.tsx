import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone } from "lucide-react";

export function AnnouncementsMarquee() {
  const { data } = useQuery({
    queryKey: ["announcements-marquee"],
    queryFn: async () => {
      const { data } = await supabase
        .from("settings")
        .select("key, value")
        .in("key", ["announcement_1", "announcement_2", "announcement_3"]);
      const m: Record<string, string> = {};
      data?.forEach((r) => (m[r.key] = typeof r.value === "string" ? r.value : ""));
      return [m.announcement_1, m.announcement_2, m.announcement_3].filter(
        (s): s is string => !!s && s.trim().length > 0,
      );
    },
  });

  const items = data ?? [];
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (items.length < 2) return;
    const t = setInterval(() => setIdx((i) => (i + 1) % items.length), 4500);
    return () => clearInterval(t);
  }, [items.length]);

  if (!items.length) return null;

  return (
    <div className="relative overflow-hidden rounded-xl border border-primary/25 bg-[image:var(--gradient-primary)]/5 px-4 py-3">
      <div className="absolute inset-0 opacity-10 bg-[image:var(--gradient-primary)] pointer-events-none" />
      <div className="relative flex items-center gap-3">
        <div className="h-8 w-8 rounded-lg bg-primary/15 text-primary flex items-center justify-center shrink-0">
          <Megaphone className="h-4 w-4" />
        </div>
        <div className="relative flex-1 h-5 overflow-hidden">
          {items.map((t, i) => (
            <p
              key={i}
              className="absolute inset-0 text-sm font-medium truncate transition-all duration-700"
              style={{
                transform: `translateY(${(i - idx) * 100}%)`,
                opacity: i === idx ? 1 : 0,
              }}
            >
              {t}
            </p>
          ))}
        </div>
        {items.length > 1 && (
          <div className="flex gap-1 shrink-0">
            {items.map((_, i) => (
              <span
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === idx ? "w-4 bg-primary" : "w-1.5 bg-primary/30"
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
