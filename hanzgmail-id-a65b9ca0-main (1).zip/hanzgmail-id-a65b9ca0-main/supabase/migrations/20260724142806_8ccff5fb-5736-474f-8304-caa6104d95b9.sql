
-- Columns
ALTER TABLE public.gmail_submissions
  ADD COLUMN IF NOT EXISTS password TEXT,
  ADD COLUMN IF NOT EXISTS note TEXT,
  ADD COLUMN IF NOT EXISTS admin_note TEXT;

ALTER TABLE public.withdrawals
  ADD COLUMN IF NOT EXISTS account_name TEXT,
  ADD COLUMN IF NOT EXISTS admin_note TEXT;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS verified BOOLEAN NOT NULL DEFAULT false;

-- Update gmail status trigger to include admin_note in rejection message
CREATE OR REPLACE FUNCTION public.on_gmail_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_balance NUMERIC(14,2);
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF NEW.status = 'approved' THEN
    UPDATE public.balances SET balance = balance + NEW.price, updated_at = now()
      WHERE user_id = NEW.user_id RETURNING balance INTO new_balance;
    INSERT INTO public.transactions (user_id, type, amount, balance_after, description, ref_id)
      VALUES (NEW.user_id, 'gmail_reward', NEW.price, new_balance, 'Gmail disetujui: ' || NEW.gmail, NEW.id);
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'gmail_approved', 'Gmail Disetujui', 'Gmail ' || NEW.gmail || ' disetujui. Saldo +Rp' || NEW.price::text);
  ELSIF NEW.status = 'rejected' THEN
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'gmail_rejected', 'Gmail Ditolak',
        'Gmail ' || NEW.gmail || ' ditolak.' || CASE WHEN COALESCE(NEW.admin_note,'') <> '' THEN ' Alasan: ' || NEW.admin_note ELSE '' END);
  END IF;
  NEW.reviewed_at := now();
  RETURN NEW;
END;
$$;

-- Update withdrawal status trigger similarly
CREATE OR REPLACE FUNCTION public.on_withdrawal_status_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_balance NUMERIC(14,2);
  cur_balance NUMERIC(14,2);
BEGIN
  IF NEW.status = OLD.status THEN
    RETURN NEW;
  END IF;
  IF NEW.status = 'approved' THEN
    SELECT balance INTO cur_balance FROM public.balances WHERE user_id = NEW.user_id FOR UPDATE;
    IF cur_balance < NEW.amount THEN
      RAISE EXCEPTION 'Saldo user tidak cukup untuk penarikan ini';
    END IF;
    UPDATE public.balances
      SET balance = balance - NEW.amount,
          total_withdrawn = total_withdrawn + NEW.amount,
          updated_at = now()
      WHERE user_id = NEW.user_id RETURNING balance INTO new_balance;
    INSERT INTO public.transactions (user_id, type, amount, balance_after, description, ref_id)
      VALUES (NEW.user_id, 'withdrawal', -NEW.amount, new_balance,
        'Penarikan ' || NEW.method::text || ' ke ' || NEW.account_number, NEW.id);
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'withdrawal_approved', 'Penarikan Disetujui',
        'Penarikan Rp' || NEW.amount::text || ' via ' || NEW.method::text || ' berhasil.');
  ELSIF NEW.status = 'rejected' THEN
    INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.user_id, 'withdrawal_rejected', 'Penarikan Ditolak',
        'Penarikan Rp' || NEW.amount::text || ' via ' || NEW.method::text || ' ditolak.' ||
        CASE WHEN COALESCE(NEW.admin_note,'') <> '' THEN ' Alasan: ' || NEW.admin_note ELSE '' END);
  END IF;
  NEW.reviewed_at := now();
  RETURN NEW;
END;
$$;

-- Verified trigger
CREATE OR REPLACE FUNCTION public.on_profile_verified()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF NEW.verified IS DISTINCT FROM OLD.verified THEN
    IF NEW.verified THEN
      INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.id, 'verified', 'Akun Diverifikasi', 'Akun Anda telah diverifikasi oleh admin.');
    ELSE
      INSERT INTO public.notifications (user_id, type, title, message)
      VALUES (NEW.id, 'unverified', 'Verifikasi Dibatalkan', 'Verifikasi akun Anda dibatalkan oleh admin.');
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_profile_verified ON public.profiles;
CREATE TRIGGER trg_profile_verified
  AFTER UPDATE OF verified ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.on_profile_verified();

-- Seed new settings (idempotent)
INSERT INTO public.settings (key, value) VALUES
  ('required_password', '"FINEIRGA"'::jsonb),
  ('max_gmail_per_submit', '10'::jsonb),
  ('max_withdrawal', '5000'::jsonb),
  ('min_withdrawal', '1000'::jsonb),
  ('discord_link', '""'::jsonb),
  ('site_status', '"active"'::jsonb),
  ('rules_text', '"RULES STOR GMAIL\n\n- Gmail wajib diakhiri 8372\n- Password wajib FINEIRGA\n- Sebelum Stor Gmail wajib cek Gmail\n- Gmail wajib ON / AKTIF\n- Gmail yang tidak sesuai akan ditolak\n- Tidak boleh mengirim Gmail yang sama"'::jsonb),
  ('banner_image', '""'::jsonb),
  ('logo_url', '""'::jsonb),
  ('primary_color', '""'::jsonb),
  ('site_name', '"HANZGMAIL"'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- Force site_name to HANZGMAIL if it's still HANZGMAIL.ID default
UPDATE public.settings SET value = '"HANZGMAIL"'::jsonb WHERE key = 'site_name' AND value::text IN ('"HANZGMAIL.ID"');
