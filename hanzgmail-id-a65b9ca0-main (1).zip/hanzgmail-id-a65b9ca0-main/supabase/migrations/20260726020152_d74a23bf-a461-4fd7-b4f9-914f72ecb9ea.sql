
REVOKE EXECUTE ON FUNCTION public.set_gmail_submission_defaults() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.guard_profile_self_update() FROM PUBLIC, anon, authenticated;
