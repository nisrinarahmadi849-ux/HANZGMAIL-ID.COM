import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/status-badge";
import { rupiah, formatDate } from "@/lib/format";
import { Search, Check, X, Trash2, Eye } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export const Route = createFileRoute("/_authenticated/admin/gmail")({
  head: () => ({ meta: [{ title: "Admin Gmail — HANZGMAIL" }] }),
  component: AdminGmail,
});

const PAGE = 20;

type Row = {
  id: string;
  created_at: string;
  user_id: string;
  gmail: string;
  password: string | null;
  note: string | null;
  admin_note: string | null;
  price: number;
  status: "pending" | "approved" | "rejected";
  username: string;
};

function AdminGmail() {
  const qc = useQueryClient();
  const [page, setPage] = useState(0);
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("all");
  const [rejectRow, setRejectRow] = useState<Row | null>(null);
  const [rejectNote, setRejectNote] = useState("");
  const [detail, setDetail] = useState<Row | null>(null);

  const { data } = useQuery({
    queryKey: ["admin-gmail", page, q, status],
    queryFn: async () => {
      let query = supabase
        .from("gmail_submissions")
        .select("*", { count: "exact" })
        .order("created_at", { ascending: false })
        .range(page * PAGE, page * PAGE + PAGE - 1);
      if (status !== "all") query = query.eq("status", status as "pending" | "approved" | "rejected");
      if (q) query = query.ilike("gmail", `%${q}%`);
      const { data, count } = await query;
      const ids = Array.from(new Set((data ?? []).map((d) => d.user_id)));
      const { data: profs } = ids.length
        ? await supabase.from("profiles").select("id, username").in("id", ids)
        : { data: [] as { id: string; username: string }[] };
      const nameMap = new Map((profs ?? []).map((p) => [p.id, p.username]));
      const rows: Row[] = (data ?? []).map((r) => ({ ...r, username: nameMap.get(r.user_id) ?? "-" }));
      return { rows, count: count ?? 0 };
    },
  });

  const approve = async (id: string) => {
    const { error } = await supabase.from("gmail_submissions").update({ status: "approved" }).eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Gmail disetujui");
      qc.invalidateQueries({ queryKey: ["admin-gmail"] });
      qc.invalidateQueries({ queryKey: ["admin-dash"] });
    }
  };

  const doReject = async () => {
    if (!rejectRow) return;
    const { error } = await supabase
      .from("gmail_submissions")
      .update({ status: "rejected", admin_note: rejectNote.trim() || null })
      .eq("id", rejectRow.id);
    if (error) toast.error(error.message);
    else {
      toast.success("Gmail ditolak");
      setRejectRow(null);
      setRejectNote("");
      qc.invalidateQueries({ queryKey: ["admin-gmail"] });
    }
  };

  const del = async (id: string) => {
    if (!confirm("Hapus data ini?")) return;
    const { error } = await supabase.from("gmail_submissions").delete().eq("id", id);
    if (error) toast.error(error.message);
    else {
      toast.success("Dihapus");
      qc.invalidateQueries({ queryKey: ["admin-gmail"] });
    }
  };

  const total = data?.count ?? 0;
  const pages = Math.max(1, Math.ceil(total / PAGE));

  return (
    <Card className="p-4 card-elevated">
      <div className="flex flex-wrap gap-2 mb-3">
        <div className="relative flex-1 min-w-56">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Cari gmail..." className="pl-8" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
        </div>
        <Select value={status} onValueChange={(v) => { setStatus(v); setPage(0); }}>
          <SelectTrigger className="w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Semua</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="approved">Disetujui</SelectItem>
            <SelectItem value="rejected">Ditolak</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tanggal</TableHead>
              <TableHead>Username</TableHead>
              <TableHead>Gmail</TableHead>
              <TableHead>Harga</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {data?.rows.map((r) => (
              <TableRow key={r.id}>
                <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatDate(r.created_at)}</TableCell>
                <TableCell>{r.username}</TableCell>
                <TableCell className="font-medium">{r.gmail}</TableCell>
                <TableCell>{rupiah(r.price)}</TableCell>
                <TableCell><StatusBadge status={r.status} /></TableCell>
                <TableCell className="text-right whitespace-nowrap">
                  <Button size="icon" variant="ghost" onClick={() => setDetail(r)} aria-label="Detail">
                    <Eye className="h-4 w-4" />
                  </Button>
                  {r.status === "pending" && (
                    <>
                      <Button size="icon" variant="ghost" onClick={() => approve(r.id)} aria-label="ACC">
                        <Check className="h-4 w-4 text-success" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => { setRejectRow(r); setRejectNote(""); }} aria-label="Tolak">
                        <X className="h-4 w-4 text-destructive" />
                      </Button>
                    </>
                  )}
                  <Button size="icon" variant="ghost" onClick={() => del(r.id)} aria-label="Hapus">
                    <Trash2 className="h-4 w-4 text-muted-foreground" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {!data?.rows.length && (
              <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6">Tidak ada data</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      <div className="flex items-center justify-between mt-3 text-sm">
        <span className="text-muted-foreground">Total: {total}</span>
        <div className="flex gap-1">
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.max(0, p - 1))} disabled={page === 0}>Prev</Button>
          <span className="px-3 py-1">{page + 1} / {pages}</span>
          <Button size="sm" variant="outline" onClick={() => setPage((p) => Math.min(pages - 1, p + 1))} disabled={page >= pages - 1}>Next</Button>
        </div>
      </div>

      {/* Reject dialog */}
      <Dialog open={!!rejectRow} onOpenChange={(o) => !o && setRejectRow(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Tolak Gmail</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Gmail: <strong>{rejectRow?.gmail}</strong></p>
            <div>
              <Label htmlFor="rn">Alasan penolakan</Label>
              <Textarea id="rn" value={rejectNote} onChange={(e) => setRejectNote(e.target.value)} placeholder="Contoh: Gmail tidak aktif" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRejectRow(null)}>Batal</Button>
            <Button variant="destructive" onClick={doReject}>Tolak</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail dialog */}
      <Dialog open={!!detail} onOpenChange={(o) => !o && setDetail(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>Detail Gmail</DialogTitle></DialogHeader>
          <div className="space-y-2 text-sm">
            <div><span className="text-muted-foreground">Gmail: </span><strong>{detail?.gmail}</strong></div>
            <div><span className="text-muted-foreground">Password: </span><code className="bg-muted px-1.5 py-0.5 rounded">{detail?.password ?? "-"}</code></div>
            <div><span className="text-muted-foreground">Catatan user: </span>{detail?.note ?? "-"}</div>
            <div><span className="text-muted-foreground">Catatan admin: </span>{detail?.admin_note ?? "-"}</div>
            <div><span className="text-muted-foreground">Status: </span><StatusBadge status={detail?.status ?? "pending"} /></div>
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
