import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    pending: { label: "Pending", cls: "bg-warning/15 text-warning border-warning/30" },
    approved: { label: "Disetujui", cls: "bg-success/15 text-success border-success/30" },
    rejected: { label: "Ditolak", cls: "bg-destructive/15 text-destructive border-destructive/30" },
    active: { label: "Aktif", cls: "bg-success/15 text-success border-success/30" },
    suspended: { label: "Suspended", cls: "bg-warning/15 text-warning border-warning/30" },
    banned: { label: "Banned", cls: "bg-destructive/15 text-destructive border-destructive/30" },
  };
  const s = map[status] ?? { label: status, cls: "bg-muted text-muted-foreground" };
  return (
    <Badge variant="outline" className={cn("font-medium", s.cls)}>
      {s.label}
    </Badge>
  );
}
