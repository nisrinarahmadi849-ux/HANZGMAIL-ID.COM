import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Wallet,
  Clock,
  CheckCircle2,
  XCircle,
  ArrowRight,
  Trophy,
  RefreshCw,
  ArrowDownToLine,
  ScrollText,
  Megaphone,
  Mail,
  MessageCircle,
  Send,
  History,
  Scale,
  ChevronLeft,
  ChevronRight,
  X,
  Tag,
} from "lucide-react";
import { rupiah } from "@/lib/format";
import { useCountUp } from "@/hooks/use-count-up";
import { useMemo, useState } from "react";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — HANZGMAIL" }] }),
  component: Dashboard,
});

function Dashboard() {
  const qc = useQueryClient();
  const { data, isFetching, refetch } = useQuery({
    queryKey: ["user-dashboard"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user!.id;
      const startOfDay = new Date();
      startOfDay.setHours(0, 0, 0, 0);
      const [balance, pending, approved, rejected, today] = await Promise.all([
        supabase.from("balances").select("balance").eq("user_id", uid).maybeSingle(),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("user_id", uid).eq("status", "pending"),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("user_id", uid).eq("status", "approved"),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("user_id", uid).eq("status", "rejected"),
        supabase.from("gmail_submissions").select("*", { count: "exact", head: true }).eq("user_id", uid).gte("created_at", startOfDay.toISOString()),
      ]);
      return {
        balance: Number(balance.data?.balance ?? 0),
        pending: pending.count ?? 0,
        approved: approved.count ?? 0,
        rejected: rejected.count ?? 0,
        today: today.count ?? 0,
      };
    },
  });

  const { data: settings } = useQuery({
    queryKey: ["dashboard-settings"],
    queryFn: async () => {
      const { data } = await supabase
        .from("settings")
        .select("key, value")
        .in("key", [
          "banner_text",
          "announcement_1",
          "announcement_2",
          "announcement_3",
          "banner_image",
          "developer_whatsapp",
          "whatsapp_admin",
          "gmail_price",
          "daily_submit_limit",
        ]);
      const m: Record<string, string> = {};
      data?.forEach((r) => (m[r.key] = typeof r.value === "string" ? r.value : String(r.value ?? "")));
      return m;
    },
  });

  const balanceDisplay = useCountUp(data?.balance ?? 0);
  const price = Number(settings?.gmail_price ?? 5000);
  const dailyLimit = Number(settings?.daily_submit_limit ?? 50);
  const todayCount = data?.today ?? 0;
  const dailyLeft = Math.max(0, dailyLimit - todayCount);
  const dailyPct = Math.min(100, Math.round((todayCount / Math.max(1, dailyLimit)) * 100));

  const totalReviewed = (data?.approved ?? 0) + (data?.rejected ?? 0);
  const qualityPct = totalReviewed === 0 ? 0 : Math.round(((data?.approved ?? 0) / totalReviewed) * 100);
  const qualityLabel =
    qualityPct >= 90 ? "Top Seller" : qualityPct >= 75 ? "Trusted Seller" : qualityPct >= 50 ? "Average Seller" : "Perlu Ditingkatkan";
  const qualityBar =
    qualityPct >= 90 ? "bg-emerald-500" : qualityPct >= 75 ? "bg-primary" : qualityPct >= 50 ? "bg-orange-500" : "bg-destructive";

  const wa = (settings?.whatsapp_admin ?? "").trim();
  const waHref = wa
    ? wa.startsWith("http")
      ? wa
      : `https://wa.me/${wa.replace(/[^0-9]/g, "")}`
    : "";

  const devWa = (settings?.developer_whatsapp ?? "").trim();
  const devWaHref = devWa ? `https://wa.me/${devWa.replace(/[^0-9]/g, "")}` : "";

  const primaryMenu: { to: "/kirim" | "/riwayat" | "/saldo" | "/rules"; label: string; icon: typeof Send; color: string }[] = [
    { to: "/kirim", label: "Stor", icon: Send, color: "bg-primary text-primary-foreground" },
    { to: "/riwayat", label: "Riwayat", icon: History, color: "bg-emerald-500 text-white" },
    { to: "/saldo", label: "Saldo", icon: Wallet, color: "bg-orange-500 text-white" },
    { to: "/rules", label: "Rules", icon: ScrollText, color: "bg-fuchsia-500 text-white" },
  ];

  const secondaryMenu: { to: "/leaderboard" | "/saluran" | "/penarikan" | "/notifikasi"; label: string; icon: typeof Trophy; color: string }[] = [
    { to: "/leaderboard", label: "Leaderboard", icon: Trophy, color: "bg-warning/10 text-warning" },
    { to: "/saluran", label: "Saluran", icon: Megaphone, color: "bg-sky-500/10 text-sky-600" },
    { to: "/penarikan", label: "Penarikan", icon: ArrowDownToLine, color: "bg-success/10 text-success" },
    { to: "/notifikasi", label: "Notifikasi", icon: MessageCircle, color: "bg-primary/10 text-primary" },
  ];

  const statusCards = [
    { label: "Diterima", value: data?.approved ?? 0, icon: CheckCircle2, color: "text-success bg-success/10" },
    { label: "Pending", value: data?.pending ?? 0, icon: Clock, color: "text-warning bg-warning/10" },
    { label: "Ditolak", value: data?.rejected ?? 0, icon: XCircle, color: "text-destructive bg-destructive/10" },
    { label: "Harga", value: rupiah(price), icon: Tag, color: "text-primary bg-primary/10" },
  ];

  return (
    <div className="space-y-5 pb-24 md:pb-6">
      {/* Header with Saluran WA */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-full bg-primary/10 text-primary flex items-center justify-center">
            <Mail className="h-4 w-4" />
          </div>
          <p className="font-display font-bold tracking-tight">HANZGMAIL</p>
        </div>
        {waHref && (
          <Button asChild variant="outline" size="sm" className="rounded-full">
            <a href={waHref} target="_blank" rel="noreferrer">
              <MessageCircle className="h-4 w-4 mr-1" /> Saluran WA
            </a>
          </Button>
        )}
      </div>

      {/* Hero Saldo */}
      <Card className="p-6 card-elevated relative overflow-hidden text-primary-foreground border-0">
        <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-primary)" }} />
        {settings?.banner_image && (
          <img src={settings.banner_image} alt="" className="absolute inset-0 h-full w-full object-cover opacity-20 pointer-events-none" />
        )}
        <div className="relative space-y-3">
          <div className="flex items-center gap-2 text-primary-foreground/80">
            <Wallet className="h-4 w-4" />
            <span className="text-xs uppercase tracking-wider font-medium">Saldo Anda</span>
          </div>
          <p className="text-4xl sm:text-5xl font-display font-bold">{rupiah(balanceDisplay)}</p>
          <p className="text-sm text-primary-foreground/85">
            Harga / Gmail: <span className="font-semibold">{rupiah(price)}</span>
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <Button asChild variant="secondary" size="sm" className="rounded-full">
              <Link to="/penarikan">
                <ArrowDownToLine className="mr-1 h-4 w-4" /> Tarik Saldo
              </Link>
            </Button>
            <Button asChild variant="secondary" size="sm" className="rounded-full">
              <Link to="/riwayat">
                <History className="mr-1 h-4 w-4" /> Riwayat
              </Link>
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="rounded-full"
              onClick={() => { refetch(); qc.invalidateQueries(); }}
              disabled={isFetching}
              aria-label="Refresh"
            >
              <RefreshCw className={`h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
            </Button>
          </div>
        </div>
      </Card>

      {/* Primary quick actions grid */}
      <Card className="p-4 card-elevated">
        <div className="grid grid-cols-4 gap-2">
          {primaryMenu.map((m) => (
            <Link key={m.to} to={m.to} className="group flex flex-col items-center gap-1.5">
              <div className={`h-14 w-14 rounded-2xl ${m.color} flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform`}>
                <m.icon className="h-6 w-6" />
              </div>
              <span className="text-xs font-medium">{m.label}</span>
            </Link>
          ))}
        </div>
      </Card>

      {/* Secondary grid */}
      <Card className="p-4 card-elevated">
        <div className="grid grid-cols-4 gap-2">
          {secondaryMenu.map((m) => (
            <Link key={m.to} to={m.to} className="group flex flex-col items-center gap-1.5">
              <div className={`h-14 w-14 rounded-2xl border ${m.color} flex items-center justify-center group-hover:scale-105 transition-transform`}>
                <m.icon className="h-6 w-6" />
              </div>
              <span className="text-xs font-medium text-center">{m.label}</span>
            </Link>
          ))}
        </div>
      </Card>

      {/* Syarat & Ketentuan */}
      <Link to="/rules">
        <Card className="p-4 card-elevated flex items-center gap-3 hover:shadow-[var(--shadow-glow)] transition-all">
          <div className="h-12 w-12 rounded-xl bg-primary text-primary-foreground flex items-center justify-center">
            <Scale className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-display font-semibold">Syarat &amp; Ketentuan</p>
            <p className="text-xs text-muted-foreground">Baca ketentuan penggunaan platform</p>
          </div>
          <ChevronRight className="h-5 w-5 text-muted-foreground" />
        </Card>
      </Link>

      {/* Status stats 2x2 */}
      <div className="grid gap-3 grid-cols-2">
        {statusCards.map((s) => (
          <Card key={s.label} className="p-4 card-elevated">
            <div className="flex items-center gap-3">
              <div className={`h-10 w-10 rounded-lg ${s.color} flex items-center justify-center shrink-0`}>
                <s.icon className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">{s.label}</p>
                <p className="text-lg font-display font-bold truncate">{s.value}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Kualitas Akun */}
      <Card className="p-4 card-elevated space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-medium">Kualitas Akun</p>
          <span className="text-xs font-medium rounded-full px-2 py-0.5 bg-orange-500/15 text-orange-600">
            {qualityPct}% · {qualityLabel}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-2xl font-display font-bold">{qualityPct}%</span>
          <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
            <div className={`h-full ${qualityBar} transition-all`} style={{ width: `${qualityPct}%` }} />
          </div>
        </div>
      </Card>

      {/* Limit Storan Hari Ini */}
      <Card className="p-4 card-elevated space-y-2">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">Limit Storan Hari Ini</p>
          <span className="text-sm">
            <span className="font-semibold">{todayCount}/{dailyLimit}</span>
            <span className="text-muted-foreground"> · Sisa </span>
            <span className="font-semibold">{dailyLeft}</span>
          </span>
        </div>
        <div className="h-1.5 rounded-full bg-muted overflow-hidden">
          <div className="h-full bg-primary transition-all" style={{ width: `${dailyPct}%` }} />
        </div>
      </Card>

      {/* Pengumuman with pagination */}
      <AnnouncementCard
        items={[settings?.announcement_1, settings?.announcement_2, settings?.announcement_3].filter(
          (x): x is string => !!x && x.trim().length > 0,
        )}
      />

      {/* Developer WhatsApp */}
      <Card className="p-4 card-elevated flex items-center gap-3">
        <div className="h-11 w-11 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0">
          <MessageCircle className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-display font-semibold text-sm">Pengembang / Developer</p>
          <p className="text-xs text-muted-foreground">Butuh bantuan? Hubungi via WhatsApp.</p>
        </div>
        {devWaHref ? (
          <Button asChild size="sm" className="bg-emerald-600 hover:bg-emerald-700 text-white">
            <a href={devWaHref} target="_blank" rel="noreferrer">
              <MessageCircle className="h-4 w-4 mr-1" /> Chat
            </a>
          </Button>
        ) : (
          <Button disabled size="sm" variant="outline">Belum diatur</Button>
        )}
      </Card>

      {/* Bottom nav (mobile) */}
      <BottomNav />
    </div>
  );
}

function AnnouncementCard({ items }: { items: string[] }) {
  const [idx, setIdx] = useState(0);
  const [closed, setClosed] = useState(false);
  const list = useMemo(() => items.slice(0, 3), [items]);
  if (closed || list.length === 0) return null;
  const total = list.length;
  const cur = list[Math.min(idx, total - 1)];
  return (
    <Card className="p-4 card-elevated border-orange-300/50 bg-gradient-to-br from-orange-50 to-emerald-50 dark:from-orange-950/30 dark:to-emerald-950/30">
      <div className="flex items-start gap-3">
        <div className="h-9 w-9 rounded-full bg-orange-500/15 text-orange-600 flex items-center justify-center shrink-0">
          <Megaphone className="h-4 w-4" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className="font-bold text-orange-700 dark:text-orange-400 text-sm">🎉 PENGUMUMAN</p>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setIdx((i) => (i - 1 + total) % total)}
                className="h-6 w-6 rounded-full hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center"
                aria-label="Sebelumnya"
              >
                <ChevronLeft className="h-4 w-4" />
              </button>
              <span className="text-xs text-muted-foreground tabular-nums">
                {Math.min(idx, total - 1) + 1}/{total}
              </span>
              <button
                type="button"
                onClick={() => setIdx((i) => (i + 1) % total)}
                className="h-6 w-6 rounded-full hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center"
                aria-label="Berikutnya"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
              <button
                type="button"
                onClick={() => setClosed(true)}
                className="h-6 w-6 rounded-full hover:bg-black/5 dark:hover:bg-white/10 flex items-center justify-center"
                aria-label="Tutup"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
          </div>
          <p className="mt-1.5 text-sm leading-relaxed whitespace-pre-wrap">{cur}</p>
        </div>
      </div>
    </Card>
  );
}

function BottomNav() {
  const items: { to: "/dashboard" | "/riwayat" | "/kirim" | "/saldo" | "/profil"; label: string; icon: typeof Wallet; center?: boolean }[] = [
    { to: "/dashboard", label: "Beranda", icon: ArrowRight },
    { to: "/riwayat", label: "Riwayat", icon: History },
    { to: "/kirim", label: "Stor", icon: Send, center: true },
    { to: "/saldo", label: "Saldo", icon: Wallet },
    { to: "/profil", label: "Profil", icon: MessageCircle },
  ];
  const iconMap = { "/dashboard": Wallet, "/riwayat": History, "/kirim": Send, "/saldo": Wallet, "/profil": MessageCircle } as const;
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 md:hidden">
      <div className="mx-auto max-w-2xl px-3 pb-3">
        <div className="rounded-2xl bg-card/95 backdrop-blur border shadow-lg px-2 py-2 flex items-end justify-around">
          {items.map((it) => {
            const Icon = iconMap[it.to];
            if (it.center) {
              return (
                <Link
                  key={it.to}
                  to={it.to}
                  className="-mt-6 flex flex-col items-center gap-0.5"
                >
                  <div className="h-14 w-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg ring-4 ring-background">
                    <Send className="h-6 w-6" />
                  </div>
                  <span className="text-[10px] font-medium text-primary">{it.label}</span>
                </Link>
              );
            }
            return (
              <Link
                key={it.to}
                to={it.to}
                className="flex flex-col items-center gap-0.5 py-1 px-2 text-muted-foreground hover:text-foreground"
              >
                <Icon className="h-5 w-5" />
                <span className="text-[10px] font-medium">{it.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
