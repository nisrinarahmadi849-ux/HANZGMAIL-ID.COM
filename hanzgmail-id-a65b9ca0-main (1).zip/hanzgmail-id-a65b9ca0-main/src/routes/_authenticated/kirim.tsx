import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Mail, Info, Plus, Trash2, ShieldCheck, Loader2, CheckCircle2, XCircle, HelpCircle, Lock } from "lucide-react";
import { toast } from "sonner";
import { rupiah, formatDate } from "@/lib/format";
import { StatusBadge } from "@/components/status-badge";
import { useServerFn } from "@tanstack/react-start";
import { checkGmailAlive } from "@/lib/gmail-check.functions";

export const Route = createFileRoute("/_authenticated/kirim")({
  head: () => ({ meta: [{ title: "Stor Gmail — HANZGMAIL" }] }),
  component: KirimPage,
});

type CheckState = { status: "idle" | "loading" | "active" | "inactive" | "invalid" | "unknown"; note?: string };
type Row = { gmail: string; check: CheckState };
const empty = (): Row => ({ gmail: "", check: { status: "idle" } });

function KirimPage() {
  const qc = useQueryClient();
  const [rows, setRows] = useState<Row[]>([empty()]);
  const [loading, setLoading] = useState(false);
  const checkFn = useServerFn(checkGmailAlive);

  const { data: settings } = useQuery({
    queryKey: ["settings-kirim"],
    queryFn: async () => {
      const { data } = await supabase
        .from("settings")
        .select("key, value")
        .in("key", ["gmail_price", "gmail_suffix", "max_gmail_per_submit", "gmail_open"]);
      const map: Record<string, unknown> = {};
      data?.forEach((r) => (map[r.key] = r.value));
      const gmailOpenRaw = map.gmail_open;
      const gmailOpen =
        gmailOpenRaw === true ||
        gmailOpenRaw === "true" ||
        gmailOpenRaw === undefined ||
        gmailOpenRaw === null;
      return {
        price: Number(map.gmail_price ?? 5000),
        suffix: String(map.gmail_suffix ?? "8372"),
        maxPerSubmit: Number(map.max_gmail_per_submit ?? 10),
        gmailOpen,
      };
    },
  });

  const { data: recent } = useQuery({
    queryKey: ["recent-submissions"],
    queryFn: async () => {
      const { data } = await supabase
        .from("gmail_submissions")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(10);
      return data ?? [];
    },
  });

  const suffix = settings?.suffix ?? "8372";
  const price = settings?.price ?? 5000;
  const max = settings?.maxPerSubmit ?? 10;
  const open = settings?.gmailOpen ?? true;

  const update = (i: number, patch: Partial<Row>) =>
    setRows((rs) => rs.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  const add = () => setRows((rs) => (rs.length >= max ? rs : [...rs, empty()]));
  const remove = (i: number) => setRows((rs) => (rs.length === 1 ? rs : rs.filter((_, idx) => idx !== i)));

  const doCheck = async (i: number) => {
    const email = rows[i].gmail.trim().toLowerCase();
    if (!email) return toast.error("Isi Gmail dulu");
    update(i, { check: { status: "loading" } });
    try {
      const res = await checkFn({ data: { email } });
      update(i, { check: { status: res.status, note: res.note } });
    } catch (e) {
      update(i, { check: { status: "unknown", note: e instanceof Error ? e.message : "error" } });
    }
  };

  const checkAll = async () => {
    for (let i = 0; i < rows.length; i++) {
      // eslint-disable-next-line no-await-in-loop
      await doCheck(i);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!open) return toast.error("Stor Gmail sedang ditutup admin");
    const cleaned = rows.map((r) => ({ gmail: r.gmail.trim().toLowerCase() }));

    for (let i = 0; i < cleaned.length; i++) {
      const r = cleaned[i];
      if (!r.gmail) return toast.error(`Baris ${i + 1}: Gmail wajib diisi`);
      if (!/^[a-z0-9._%+-]+@gmail\.com$/i.test(r.gmail)) return toast.error(`Baris ${i + 1}: Format Gmail tidak valid`);
      const local = r.gmail.split("@")[0];
      if (!local.endsWith(suffix)) return toast.error(`Baris ${i + 1}: Gmail wajib diakhiri "${suffix}"`);
    }
    const dupes = new Set<string>();
    for (const r of cleaned) {
      if (dupes.has(r.gmail)) return toast.error(`Gmail duplikat dalam batch: ${r.gmail}`);
      dupes.add(r.gmail);
    }

    setLoading(true);
    const { data: userData } = await supabase.auth.getUser();
    const uid = userData.user!.id;
    const payload = cleaned.map((r) => ({
      user_id: uid,
      gmail: r.gmail,
      price,
    }));
    const { error } = await supabase.from("gmail_submissions").insert(payload);
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success(`${payload.length} Gmail dikirim, menunggu persetujuan admin.`);
    setRows([empty()]);
    qc.invalidateQueries({ queryKey: ["recent-submissions"] });
    qc.invalidateQueries({ queryKey: ["user-dashboard"] });
  };

  return (
    <div className="max-w-4xl space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Stor Gmail</h1>
        <p className="text-sm text-muted-foreground">
          Dapatkan {rupiah(price)} per Gmail disetujui · Maksimal {max} Gmail sekali kirim
        </p>
      </div>

      {!open && (
        <Card className="p-4 card-elevated border-destructive/40 bg-destructive/5">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-lg bg-destructive/15 text-destructive flex items-center justify-center shrink-0">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <p className="font-display font-semibold">Stor Gmail Sedang Ditutup</p>
              <p className="text-sm text-muted-foreground">
                Admin sedang menutup penerimaan Gmail. Silakan cek kembali nanti.
              </p>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 card-elevated">
        <div className="flex items-start gap-3 mb-4 p-3 rounded-lg bg-primary/5 border border-primary/20">
          <Info className="h-4 w-4 text-primary mt-0.5 shrink-0" />
          <div className="text-sm">
            <p className="font-medium">Syarat pengiriman:</p>
            <ul className="list-disc list-inside text-muted-foreground mt-1 space-y-0.5 text-xs">
              <li>Gmail wajib aktif / live dan sudah dicek.</li>
              <li>Nama akun wajib diakhiri <code className="bg-muted px-1 rounded">{suffix}</code>.</li>
              <li>Tidak boleh mengirim Gmail yang sama.</li>
            </ul>
          </div>
        </div>

        <form onSubmit={submit} className="space-y-4">
          {rows.map((r, i) => (
            <div key={i} className="grid gap-2 sm:grid-cols-[1fr_auto] sm:items-end p-3 rounded-lg border bg-card/50">
              <div>
                <Label className="text-xs flex items-center gap-2">
                  Gmail #{i + 1}
                  <CheckPill state={r.check} />
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder={`namakamu${suffix}@gmail.com`}
                    className="pl-9"
                    value={r.gmail}
                    onChange={(e) => update(i, { gmail: e.target.value, check: { status: "idle" } })}
                  />
                </div>
              </div>
              <div className="flex gap-1">
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => doCheck(i)}
                  disabled={r.check.status === "loading"}
                  aria-label="Cek Gmail"
                  title="Cek apakah akun Google aktif"
                >
                  {r.check.status === "loading" ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <ShieldCheck className="h-4 w-4 text-primary" />
                  )}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => remove(i)}
                  disabled={rows.length === 1}
                  aria-label="Hapus baris"
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </div>
            </div>
          ))}

          <div className="flex flex-wrap gap-2">
            <Button type="button" variant="outline" onClick={add} disabled={rows.length >= max}>
              <Plus className="h-4 w-4 mr-1" /> Tambah baris
            </Button>
            <Button type="button" variant="outline" onClick={checkAll}>
              <ShieldCheck className="h-4 w-4 mr-1" /> Cek Semua
            </Button>
            <Button type="submit" disabled={loading || !open}>
              {loading ? "Mengirim..." : `Kirim ${rows.length} Gmail`}
            </Button>
          </div>
        </form>
      </Card>

      <Card className="p-5 card-elevated">
        <h3 className="font-display font-semibold mb-3">Pengiriman Terbaru</h3>
        <div className="space-y-2">
          {recent?.map((r) => (
            <div key={r.id} className="flex items-center justify-between p-2 rounded-md hover:bg-accent text-sm gap-2">
              <div className="min-w-0">
                <p className="truncate">{r.gmail}</p>
                <p className="text-xs text-muted-foreground">{formatDate(r.created_at)}</p>
              </div>
              <div className="flex items-center gap-3 shrink-0">
                <span className="font-semibold text-sm hidden sm:inline">{rupiah(r.price)}</span>
                <StatusBadge status={r.status} />
              </div>
            </div>
          ))}
          {!recent?.length && <p className="text-xs text-muted-foreground">Belum ada pengiriman</p>}
        </div>
      </Card>
    </div>
  );
}

function CheckPill({ state }: { state: CheckState }) {
  if (state.status === "idle") return null;
  const map = {
    loading: { cls: "bg-muted text-muted-foreground", label: "Mengecek...", Icon: Loader2, spin: true },
    active: { cls: "bg-success/15 text-success", label: "Aktif", Icon: CheckCircle2, spin: false },
    inactive: { cls: "bg-destructive/15 text-destructive", label: "Tidak Aktif", Icon: XCircle, spin: false },
    invalid: { cls: "bg-destructive/15 text-destructive", label: "Format Salah", Icon: XCircle, spin: false },
    unknown: { cls: "bg-warning/15 text-warning", label: "Tidak Diketahui", Icon: HelpCircle, spin: false },
  } as const;
  const m = map[state.status];
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium ${m.cls}`}
      title={state.note}
    >
      <m.Icon className={`h-3 w-3 ${m.spin ? "animate-spin" : ""}`} />
      {m.label}
    </span>
  );
}
