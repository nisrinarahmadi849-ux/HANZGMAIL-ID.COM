import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { rupiah, formatDate } from "@/lib/format";
import { StatusBadge } from "@/components/status-badge";
import { Lock, Save } from "lucide-react";

export const Route = createFileRoute("/_authenticated/penarikan")({
  head: () => ({ meta: [{ title: "Penarikan — HANZGMAIL" }] }),
  component: WdPage,
});

function WdPage() {
  const qc = useQueryClient();
  const [method, setMethod] = useState<"dana" | "gopay">("dana");
  const [accountName, setAccountName] = useState("");
  const [account, setAccount] = useState("");
  const [amount, setAmount] = useState("");
  const [loading, setLoading] = useState(false);
  const [savingBank, setSavingBank] = useState(false);
  const [uid, setUid] = useState<string | null>(null);

  const { data } = useQuery({
    queryKey: ["wd-page"],
    queryFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const userId = userData.user!.id;
      const [balance, list, settings, profile] = await Promise.all([
        supabase.from("balances").select("balance").eq("user_id", userId).maybeSingle(),
        supabase.from("withdrawals").select("*").eq("user_id", userId).order("created_at", { ascending: false }).limit(50),
        supabase.from("settings").select("key, value").in("key", ["min_withdrawal", "max_withdrawal", "withdrawal_open"]),
        supabase.from("profiles").select("bank_method, bank_account_name, bank_account_number").eq("id", userId).maybeSingle(),
      ]);
      const m: Record<string, unknown> = {};
      settings.data?.forEach((r) => (m[r.key] = r.value));
      const wdOpenRaw = m.withdrawal_open;
      const withdrawalOpen =
        wdOpenRaw === true || wdOpenRaw === "true" || wdOpenRaw === undefined || wdOpenRaw === null;
      return {
        uid: userId,
        balance: Number(balance.data?.balance ?? 0),
        list: list.data ?? [],
        min: Number(m.min_withdrawal ?? 1000),
        max: Number(m.max_withdrawal ?? 5000),
        withdrawalOpen,
        profile: profile.data,
      };
    },
  });

  const min = data?.min ?? 1000;
  const max = data?.max ?? 5000;
  const open = data?.withdrawalOpen ?? true;

  useEffect(() => {
    if (data?.uid) setUid(data.uid);
    if (data?.profile) {
      const p = data.profile;
      if (p.bank_method === "dana" || p.bank_method === "gopay") setMethod(p.bank_method);
      if (p.bank_account_name) setAccountName(p.bank_account_name);
      if (p.bank_account_number) setAccount(p.bank_account_number);
    }
  }, [data]);

  const saveBank = async () => {
    if (!uid) return;
    if (!accountName.trim() || !/^\d{9,15}$/.test(account.trim())) {
      return toast.error("Nama & nomor rekening tidak valid");
    }
    setSavingBank(true);
    const { error } = await supabase
      .from("profiles")
      .update({
        bank_method: method,
        bank_account_name: accountName.trim(),
        bank_account_number: account.trim(),
      })
      .eq("id", uid);
    setSavingBank(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Rekening tersimpan");
      qc.invalidateQueries({ queryKey: ["wd-page"] });
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!open) return toast.error("Penarikan sedang ditutup admin");
    if (!accountName.trim()) return toast.error("Nama pemilik wajib diisi");
    if (!/^\d{9,15}$/.test(account.trim())) return toast.error("Nomor tujuan tidak valid");
    const amt = Number(amount);
    if (!amt || amt < min) return toast.error(`Minimal penarikan ${rupiah(min)}`);
    if (amt > max) return toast.error(`Maksimal penarikan ${rupiah(max)}`);
    if (amt > (data?.balance ?? 0)) return toast.error("Saldo tidak mencukupi");
    setLoading(true);
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from("withdrawals").insert({
      user_id: userData.user!.id,
      method,
      account_name: accountName.trim(),
      account_number: account.trim(),
      amount: amt,
    });
    setLoading(false);
    if (error) toast.error(error.message);
    else {
      toast.success("Permintaan penarikan dikirim");
      setAmount("");
      qc.invalidateQueries({ queryKey: ["wd-page"] });
      qc.invalidateQueries({ queryKey: ["user-dashboard"] });
    }
  };

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-display font-bold">Penarikan Saldo</h1>
        <p className="text-sm text-muted-foreground">
          Saldo tersedia: <strong className="text-foreground">{rupiah(data?.balance ?? 0)}</strong> · Batas {rupiah(min)}–{rupiah(max)}
        </p>
      </div>

      {!open && (
        <Card className="p-4 card-elevated border-destructive/40 bg-destructive/5">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-lg bg-destructive/15 text-destructive flex items-center justify-center shrink-0">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <p className="font-display font-semibold">Penarikan Sedang Ditutup</p>
              <p className="text-sm text-muted-foreground">
                Admin sedang menutup penarikan. Silakan cek kembali nanti.
              </p>
            </div>
          </div>
        </Card>
      )}

      <Card className="p-6 card-elevated">
        <form onSubmit={submit} className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label>Metode</Label>
            <Select value={method} onValueChange={(v) => setMethod(v as "dana" | "gopay")}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dana">DANA</SelectItem>
                <SelectItem value="gopay">GoPay</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="nm">Nama Pemilik</Label>
            <Input id="nm" placeholder="Nama sesuai akun" value={accountName} onChange={(e) => setAccountName(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="no">Nomor Tujuan</Label>
            <Input id="no" inputMode="numeric" placeholder="08xxxxxxxxxx" value={account} onChange={(e) => setAccount(e.target.value)} required />
          </div>
          <div>
            <Label htmlFor="am">Nominal</Label>
            <Input id="am" type="number" min={min} max={max} placeholder={String(min)} value={amount} onChange={(e) => setAmount(e.target.value)} required />
          </div>
          <div className="sm:col-span-2 flex flex-wrap gap-2">
            <Button type="submit" disabled={loading || !open}>
              {loading ? "Mengirim..." : "Ajukan Penarikan"}
            </Button>
            <Button type="button" variant="outline" onClick={saveBank} disabled={savingBank}>
              <Save className="h-4 w-4 mr-1" />
              {savingBank ? "Menyimpan..." : "Simpan Rekening"}
            </Button>
          </div>
        </form>
      </Card>

      <Card className="p-5 card-elevated">
        <h3 className="font-display font-semibold mb-3">Riwayat Penarikan</h3>
        <div className="space-y-2">
          {data?.list.map((w) => (
            <div key={w.id} className="p-2 rounded-md hover:bg-accent text-sm">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-medium truncate">
                    {w.method.toUpperCase()} · {w.account_name ?? "-"} · {w.account_number}
                  </p>
                  <p className="text-xs text-muted-foreground">{formatDate(w.created_at)}</p>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="font-semibold">{rupiah(w.amount)}</span>
                  <StatusBadge status={w.status} />
                </div>
              </div>
              {w.status === "rejected" && w.admin_note && (
                <p className="mt-1 text-xs text-destructive">Alasan: {w.admin_note}</p>
              )}
            </div>
          ))}
          {!data?.list.length && <p className="text-xs text-muted-foreground">Belum ada penarikan</p>}
        </div>
      </Card>
    </div>
  );
}
